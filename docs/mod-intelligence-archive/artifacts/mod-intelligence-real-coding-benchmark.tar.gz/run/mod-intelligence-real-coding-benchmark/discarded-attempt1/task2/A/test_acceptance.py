import copy
import math
import unittest
from solution import load_contract, WorkflowError, float32

class CodingTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls): cls.c,_=load_contract()

    def test_new_request_couples_duration_and_multiplier(self):
        r=self.c.request_preview(3)
        self.assertEqual(r['operation'],'ADD')
        self.assertEqual(r['modifier'],dict(max_duration=8,multiplier=2.5,radius=10.0))
        self.assertFalse(r['sync_existing_client'])

    def test_float32_rounding_precedes_ceil(self):
        rate=1.00000006
        expected=math.ceil(float32(float32(3599)*float32(rate)))
        self.assertEqual(self.c.request_preview(3599,request_multiplier=rate)['modifier']['max_duration'],expected)

    def test_refresh_updates_only_duration_without_reset_or_sync(self):
        old=dict(max_duration=100,multiplier=2.0,radius=3.0,master_ticks=41,entity_id=12,dimension='old',entity_type='player')
        saved=copy.deepcopy(old); r=self.c.request_preview(3,existing_modifier=old)
        self.assertEqual(r['operation'],'UPDATE_MAX_DURATION_ONLY')
        self.assertEqual(r['modifier'],dict(old,max_duration=8)); self.assertEqual(old,saved)
        self.assertFalse(r['sync_existing_client'])

    def test_new_controller_query_uses_stored_new_multiplier_twice(self):
        r=self.c.controller_query(0,duration=3,request_multiplier=2.5)
        self.assertEqual(r['max_duration'],8); self.assertEqual(r['local_multiplier'],2.5)
        self.assertEqual(r['client_tick_ms'],312.5); self.assertEqual(r['server_tick_ms'],50)
        self.assertEqual(r['client_expiry_master_tick'],3.2)
        self.assertAlmostEqual(r['client_speed_return'],0.3,places=6)
        self.assertAlmostEqual(r['client_flying_return'],0.15,places=6)

    def test_refresh_query_uses_retained_rate_radius_and_expiry(self):
        old=dict(max_duration=100,multiplier=2.0,radius=3.0,dimension='old')
        r=self.c.controller_query(2,duration=3,request_multiplier=2.5,existing_modifier=old)
        self.assertEqual((r['max_duration'],r['local_multiplier'],r['radius']),(8,2.0,3.0))
        self.assertEqual((r['client_tick_ms'],r['client_expiry_master_tick']),(200.0,4.0))
        self.assertFalse(self.c.controller_query(3,duration=3,request_multiplier=2.5,existing_modifier=old)['local_query_applies'])
        self.assertFalse(self.c.controller_query(0,duration=3,master_ticks=4,request_multiplier=2.5,existing_modifier=old)['local_query_applies'])

    def test_owner_validity_and_configuration_gates_preserved(self):
        for option in ('owner_has_sugar_rush','entity_valid','local_modifier_present'):
            with self.subTest(option=option):
                r=self.c.controller_query(0,duration=3,request_multiplier=2.5,**{option:False})
                self.assertEqual(r['client_tick_ms'],50); self.assertEqual(r['client_speed_return'],0.1)
        for option in ('config','recipient_has_sugar_rush'):
            with self.subTest(option=option):
                r=self.c.controller_query(0,duration=3,request_multiplier=2.5,**{option:False})
                self.assertEqual(r['client_tick_ms'],312.5); self.assertEqual(r['client_speed_return'],0.1)

    def test_old_default_behavior_is_unchanged(self):
        r=self.c.controller_query(0)
        self.assertEqual((r['max_duration'],r['local_multiplier'],r['client_tick_ms']),(3600,2.0,200))
        self.assertEqual(self.c.duration_multiplier,2.0); self.assertEqual(self.c.local_multiplier,2.0)

    def test_invalid_duration_and_multiplier_fail_explicitly(self):
        for duration in (True,0,-1,3601,1.5):
            with self.subTest(duration=duration),self.assertRaises(WorkflowError): self.c.request_preview(duration)
        for rate in (True,0,-1,float('nan'),float('inf'),1e100,'2.5'):
            with self.subTest(rate=rate),self.assertRaises(WorkflowError): self.c.request_preview(3,request_multiplier=rate)

    def test_refresh_preserves_extra_fields_and_result_isolation(self):
        old=dict(max_duration=100,multiplier=2.0,radius=10.0,meta={'a':[]})
        r=self.c.request_preview(3,existing_modifier=old); r['modifier']['meta']['a'].append(1)
        self.assertEqual(old['meta']['a'],[])
