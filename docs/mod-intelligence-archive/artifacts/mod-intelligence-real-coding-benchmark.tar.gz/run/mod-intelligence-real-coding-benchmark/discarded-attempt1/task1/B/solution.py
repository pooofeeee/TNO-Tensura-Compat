"""Static admitted-drop preview, not a native gameplay implementation."""
import copy
import math
from collections.abc import Mapping
from decimal import Decimal
from numbers import Real


def _heal_amount(value):
    if isinstance(value, bool) or not isinstance(value, (Real, Decimal)):
        raise ValueError('heal_amount must be a finite positive real number')
    try:
        amount = float(value)
    except (OverflowError, TypeError, ValueError) as exc:
        raise ValueError('heal_amount must be a finite positive real number') from exc
    if not math.isfinite(amount) or amount <= 0:
        raise ValueError('heal_amount must be a finite positive real number')
    return amount


def deliver(state, item, heal_amount=5.0):
    amount = _heal_amount(heal_amount)
    if not isinstance(item, Mapping):
        raise ValueError('item must be a mapping')
    result = copy.deepcopy(state)
    admitted = bool(item.get('food', False) or item.get('breed_tag', False))
    out = dict(state=result, consumed=int(admitted), remainder=None,
               heal_requested=None, health_delta=0.0)
    if not admitted:
        return out
    if item.get('maraca', False):
        result['maracas'] = True
        return out
    out['remainder'] = copy.deepcopy(item.get('remainder'))
    out['heal_requested'] = amount
    if result['health'] > 0:
        result['health'] = min(result['max_health'], result['health'] + amount)
    out['health_delta'] = result['health'] - state['health']
    if item.get('foodstuffs', False):
        result['breaded'] = True
    return out


def preview_items(state, items, *, heal_amount=6.0):
    """Carry state through ordered callbacks, returning independent snapshots."""
    amount = _heal_amount(heal_amount)
    if isinstance(items, (str, bytes, bytearray, Mapping)):
        raise ValueError('items must be an iterable of item mappings')
    try:
        iterator = iter(items)
    except TypeError as exc:
        raise ValueError('items must be an iterable of item mappings') from exc
    current = copy.deepcopy(state)
    trace = []
    for item in iterator:
        entry = deliver(current, item, heal_amount=amount)
        trace.append(entry)
        current = entry['state']
    return dict(state=copy.deepcopy(current), trace=trace)
