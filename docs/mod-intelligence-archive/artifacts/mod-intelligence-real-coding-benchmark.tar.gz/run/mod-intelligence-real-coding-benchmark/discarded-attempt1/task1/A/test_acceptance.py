import copy
import math
import unittest
from solution import deliver, preview_items

class LocalHealingTests(unittest.TestCase):
    def state(self, health=2.0):
        return dict(health=health, max_health=20.0, maracas=False, breaded=False)

    def test_old_single_item_call_remains_five(self):
        self.assertEqual(deliver(self.state(), {'food':True})['state']['health'],7.0)

    def test_batch_requests_six_and_processes_in_order(self):
        state=self.state(); drops=[{'food':True},{'breed_tag':True}]
        result=preview_items(state,drops)
        self.assertEqual(result['state']['health'],14.0)
        self.assertEqual([r['state']['health'] for r in result['trace']],[8.0,14.0])
        self.assertEqual([r['heal_requested'] for r in result['trace']],[6.0,6.0])

    def test_heal_caps_and_dead_health_stays_dead(self):
        for initial,expected in [(19.0,20.0),(20.0,20.0),(0.0,0.0)]:
            with self.subTest(initial=initial):
                r=preview_items(self.state(initial),[{'food':True}])['trace'][0]
                self.assertEqual(r['state']['health'],expected)
                self.assertEqual(r['heal_requested'],6.0)
                self.assertEqual(r['health_delta'],expected-initial)

    def test_maraca_branch_skips_remainder_heal_and_breaded(self):
        r=preview_items(self.state(),[{'breed_tag':True,'maraca':True,'remainder':'bowl','foodstuffs':True}])['trace'][0]
        self.assertTrue(r['state']['maracas']); self.assertFalse(r['state']['breaded'])
        self.assertEqual(r['state']['health'],2.0); self.assertIsNone(r['remainder'])
        self.assertIsNone(r['heal_requested']); self.assertEqual(r['consumed'],1)

    def test_food_or_breed_tag_admission_and_one_consumption(self):
        r=preview_items(self.state(),[{'food':True,'count':9},{'breed_tag':True},{'foodstuffs':True}])
        self.assertEqual([x['consumed'] for x in r['trace']],[1,1,0])
        self.assertEqual(r['state']['health'],14.0)

    def test_remainder_and_foodstuffs_are_independent_of_food_admission(self):
        r=preview_items(self.state(),[{'food':True,'remainder':'bowl'},{'breed_tag':True,'foodstuffs':True}])
        self.assertEqual(r['trace'][0]['remainder'],'bowl')
        self.assertFalse(r['trace'][0]['state']['breaded']); self.assertTrue(r['state']['breaded'])

    def test_preserves_other_actor_fields_and_does_not_claim_immunity(self):
        state=dict(self.state(),owner=None,poison_immune=False,ai={'avoid_light':True})
        r=preview_items(state,[{'food':True,'foodstuffs':True}])
        self.assertFalse(r['state']['poison_immune']); self.assertEqual(r['state']['ai'],state['ai'])
        self.assertIsNone(r['state']['owner'])

    def test_empty_batch_and_custom_policy(self):
        self.assertEqual(preview_items(self.state(),[])['trace'],[])
        self.assertEqual(preview_items(self.state(),[{'food':True}],heal_amount=3.5)['state']['health'],5.5)

    def test_invalid_healing_rejected_explicitly(self):
        for amount in [True,None,-1,0,float('nan'),float('inf'),'6']:
            with self.subTest(amount=amount),self.assertRaises(ValueError):
                preview_items(self.state(),[{'food':True}],heal_amount=amount)

    def test_input_and_trace_snapshot_isolation(self):
        state=self.state(); state['meta']={'tags':[]}; drops=[{'food':True},{'food':True}]
        original=copy.deepcopy((state,drops)); r=preview_items(state,drops)
        self.assertEqual((state,drops),original)
        r['trace'][0]['state']['meta']['tags'].append('edited')
        self.assertEqual(r['trace'][1]['state']['meta']['tags'],[])
        self.assertEqual(r['state']['meta']['tags'],[])

    def test_invalid_later_item_does_not_modify_inputs(self):
        state=self.state(); drops=[{'food':True},None]; original=copy.deepcopy((state,drops))
        with self.assertRaises(ValueError): preview_items(state,drops)
        self.assertEqual((state,drops),original)
