"""Freeze evaluation fixtures and acceptance tests; never modify catalog/tooling."""
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import tarfile

ROOT = Path('/workspace/mod-intelligence-v1')
OUT = ROOT / 'run/mod-intelligence-real-coding-benchmark'
COMMIT = 'e0918e782355756f718a1adcff1f346a26230327'
SOURCE = OUT / 'source'
SOURCE.mkdir(exist_ok=True)
archive = subprocess.check_output(['git', 'archive', COMMIT, 'scripts/external-effects',
    'docs/mod-intelligence-v1.md', 'docs/mod-intelligence-v3.md', 'docs/mod-intelligence-v4.md',
    'docs/mod-intelligence-workflow-validation.md'], cwd=ROOT)
import io
with tarfile.open(fileobj=io.BytesIO(archive)) as t:
    t.extractall(SOURCE, filter='data')
(SOURCE/'docs/benchmarks').mkdir(exist_ok=True)
if not (SOURCE/'docs/benchmarks/external-effects-catalog').exists():
    (SOURCE/'docs/benchmarks/external-effects-catalog').symlink_to(ROOT/'docs/benchmarks/external-effects-catalog', target_is_directory=True)
CLI = SOURCE/'scripts/external-effects/mod_intelligence.py'

ROACH = '''"""Static admitted-drop preview, not a native gameplay implementation."""
import copy

def deliver(state, item):
    result = copy.deepcopy(state)
    admitted = item.get('food', False) or item.get('breed_tag', False)
    out = dict(state=result, consumed=int(admitted), remainder=None,
               heal_requested=None, health_delta=0.0)
    if not admitted:
        return out
    if item.get('maraca', False):
        result['maracas'] = True
        return out
    out['remainder'] = item.get('remainder')
    out['heal_requested'] = 5.0
    if result['health'] > 0:
        result['health'] = min(result['max_health'], result['health'] + 5.0)
    out['health_delta'] = result['health'] - state['health']
    if item.get('foodstuffs', False):
        result['breaded'] = True
    return out
'''

TEST1 = '''import copy
import math
import unittest
from solution import deliver, preview_items

class LocalHealingTests(unittest.TestCase):
    def state(self, health=2.0):
        return dict(health=health, max_health=20.0, maracas=False, breaded=False)

    def test_old_single_item_call_remains_five(self):
        self.assertEqual(deliver(self.state(), {'food':True})['state']['health'],7.0)

    def test_batch_requests_six_and_processes_in_order(self):
        state=self.state(); drops=[{'food':True},{'breed_tag':True}]
        result=preview_items(state,drops)
        self.assertEqual(result['state']['health'],14.0)
        self.assertEqual([r['state']['health'] for r in result['trace']],[8.0,14.0])
        self.assertEqual([r['heal_requested'] for r in result['trace']],[6.0,6.0])

    def test_heal_caps_and_dead_health_stays_dead(self):
        for initial,expected in [(19.0,20.0),(20.0,20.0),(0.0,0.0)]:
            with self.subTest(initial=initial):
                r=preview_items(self.state(initial),[{'food':True}])['trace'][0]
                self.assertEqual(r['state']['health'],expected)
                self.assertEqual(r['heal_requested'],6.0)
                self.assertEqual(r['health_delta'],expected-initial)

    def test_maraca_branch_skips_remainder_heal_and_breaded(self):
        r=preview_items(self.state(),[{'breed_tag':True,'maraca':True,'remainder':'bowl','foodstuffs':True}])['trace'][0]
        self.assertTrue(r['state']['maracas']); self.assertFalse(r['state']['breaded'])
        self.assertEqual(r['state']['health'],2.0); self.assertIsNone(r['remainder'])
        self.assertIsNone(r['heal_requested']); self.assertEqual(r['consumed'],1)

    def test_food_or_breed_tag_admission_and_one_consumption(self):
        r=preview_items(self.state(),[{'food':True,'count':9},{'breed_tag':True},{'foodstuffs':True}])
        self.assertEqual([x['consumed'] for x in r['trace']],[1,1,0])
        self.assertEqual(r['state']['health'],14.0)

    def test_remainder_and_foodstuffs_are_independent_of_food_admission(self):
        r=preview_items(self.state(),[{'food':True,'remainder':'bowl'},{'breed_tag':True,'foodstuffs':True}])
        self.assertEqual(r['trace'][0]['remainder'],'bowl')
        self.assertFalse(r['trace'][0]['state']['breaded']); self.assertTrue(r['state']['breaded'])

    def test_preserves_other_actor_fields_and_does_not_claim_immunity(self):
        state=dict(self.state(),owner=None,poison_immune=False,ai={'avoid_light':True})
        r=preview_items(state,[{'food':True,'foodstuffs':True}])
        self.assertFalse(r['state']['poison_immune']); self.assertEqual(r['state']['ai'],state['ai'])
        self.assertIsNone(r['state']['owner'])

    def test_empty_batch_and_custom_policy(self):
        self.assertEqual(preview_items(self.state(),[])['trace'],[])
        self.assertEqual(preview_items(self.state(),[{'food':True}],heal_amount=3.5)['state']['health'],5.5)

    def test_invalid_healing_rejected_explicitly(self):
        for amount in [True,None,-1,0,float('nan'),float('inf'),'6']:
            with self.subTest(amount=amount),self.assertRaises(ValueError):
                preview_items(self.state(),[{'food':True}],heal_amount=amount)

    def test_input_and_trace_snapshot_isolation(self):
        state=self.state(); state['meta']={'tags':[]}; drops=[{'food':True},{'food':True}]
        original=copy.deepcopy((state,drops)); r=preview_items(state,drops)
        self.assertEqual((state,drops),original)
        r['trace'][0]['state']['meta']['tags'].append('edited')
        self.assertEqual(r['trace'][1]['state']['meta']['tags'],[])
        self.assertEqual(r['state']['meta']['tags'],[])

    def test_invalid_later_item_does_not_modify_inputs(self):
        state=self.state(); drops=[{'food':True},None]; original=copy.deepcopy((state,drops))
        with self.assertRaises(ValueError): preview_items(state,drops)
        self.assertEqual((state,drops),original)
'''

SUGAR_SETUP = '''import copy
import math
import unittest
from solution import load_contract, WorkflowError, float32

class CodingTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls): cls.c,_=load_contract()
'''

TEST2 = SUGAR_SETUP + '''
    def test_new_request_couples_duration_and_multiplier(self):
        r=self.c.request_preview(3)
        self.assertEqual(r['operation'],'ADD')
        self.assertEqual(r['modifier'],dict(max_duration=8,multiplier=2.5,radius=10.0))
        self.assertFalse(r['sync_existing_client'])

    def test_float32_rounding_precedes_ceil(self):
        rate=1.00000006
        expected=math.ceil(float32(float32(3599)*float32(rate)))
        self.assertEqual(self.c.request_preview(3599,request_multiplier=rate)['modifier']['max_duration'],expected)

    def test_refresh_updates_only_duration_without_reset_or_sync(self):
        old=dict(max_duration=100,multiplier=2.0,radius=3.0,master_ticks=41,entity_id=12,dimension='old',entity_type='player')
        saved=copy.deepcopy(old); r=self.c.request_preview(3,existing_modifier=old)
        self.assertEqual(r['operation'],'UPDATE_MAX_DURATION_ONLY')
        self.assertEqual(r['modifier'],dict(old,max_duration=8)); self.assertEqual(old,saved)
        self.assertFalse(r['sync_existing_client'])

    def test_new_controller_query_uses_stored_new_multiplier_twice(self):
        r=self.c.controller_query(0,duration=3,request_multiplier=2.5)
        self.assertEqual(r['max_duration'],8); self.assertEqual(r['local_multiplier'],2.5)
        self.assertEqual(r['client_tick_ms'],312.5); self.assertEqual(r['server_tick_ms'],50)
        self.assertEqual(r['client_expiry_master_tick'],3.2)
        self.assertAlmostEqual(r['client_speed_return'],0.3,places=6)
        self.assertAlmostEqual(r['client_flying_return'],0.15,places=6)

    def test_refresh_query_uses_retained_rate_radius_and_expiry(self):
        old=dict(max_duration=100,multiplier=2.0,radius=3.0,dimension='old')
        r=self.c.controller_query(2,duration=3,request_multiplier=2.5,existing_modifier=old)
        self.assertEqual((r['max_duration'],r['local_multiplier'],r['radius']),(8,2.0,3.0))
        self.assertEqual((r['client_tick_ms'],r['client_expiry_master_tick']),(200.0,4.0))
        self.assertFalse(self.c.controller_query(3,duration=3,request_multiplier=2.5,existing_modifier=old)['local_query_applies'])
        self.assertFalse(self.c.controller_query(0,duration=3,master_ticks=4,request_multiplier=2.5,existing_modifier=old)['local_query_applies'])

    def test_owner_validity_and_configuration_gates_preserved(self):
        for option in ('owner_has_sugar_rush','entity_valid','local_modifier_present'):
            with self.subTest(option=option):
                r=self.c.controller_query(0,duration=3,request_multiplier=2.5,**{option:False})
                self.assertEqual(r['client_tick_ms'],50); self.assertEqual(r['client_speed_return'],0.1)
        for option in ('config','recipient_has_sugar_rush'):
            with self.subTest(option=option):
                r=self.c.controller_query(0,duration=3,request_multiplier=2.5,**{option:False})
                self.assertEqual(r['client_tick_ms'],312.5); self.assertEqual(r['client_speed_return'],0.1)

    def test_old_default_behavior_is_unchanged(self):
        r=self.c.controller_query(0)
        self.assertEqual((r['max_duration'],r['local_multiplier'],r['client_tick_ms']),(3600,2.0,200))
        self.assertEqual(self.c.duration_multiplier,2.0); self.assertEqual(self.c.local_multiplier,2.0)

    def test_invalid_duration_and_multiplier_fail_explicitly(self):
        for duration in (True,0,-1,3601,1.5):
            with self.subTest(duration=duration),self.assertRaises(WorkflowError): self.c.request_preview(duration)
        for rate in (True,0,-1,float('nan'),float('inf'),1e100,'2.5'):
            with self.subTest(rate=rate),self.assertRaises(WorkflowError): self.c.request_preview(3,request_multiplier=rate)

    def test_refresh_preserves_extra_fields_and_result_isolation(self):
        old=dict(max_duration=100,multiplier=2.0,radius=10.0,meta={'a':[]})
        r=self.c.request_preview(3,existing_modifier=old); r['modifier']['meta']['a'].append(1)
        self.assertEqual(old['meta']['a'],[])
'''

TEST3 = SUGAR_SETUP + '''
    def frames(self):
        return [dict(velocity=(1,2,3),on_server=True,remaining_duration=10,slow_falling_present=False),
                dict(velocity=(4,-2,6),on_server=True,remaining_duration=10,slow_falling_present=False),
                dict(velocity=(7,-3,9),on_server=False,remaining_duration=10,slow_falling_present=False)]

    def test_ordered_trace_changes_upward_server_y_only(self):
        r=self.c.preview_frames(self.frames())
        self.assertEqual([x['velocity'] for x in r],[(1,1.9,3),(4,-0.9,6),(7,-3,9)])
        self.assertEqual([x['effect_tick_return'] for x in r],[True,True,True])

    def test_client_sound_is_observable_and_does_not_move(self):
        r=self.c.preview_frames([self.frames()[2]])[0]
        self.assertEqual(r['actions'],['NATIVE_SOUND']); self.assertIsNone(r['slow_falling_request'])

    def test_slow_falling_has_original_duration_amplifier_and_flags(self):
        r=self.c.preview_frames([self.frames()[1]])[0]
        self.assertEqual(r['actions'],['SET_MOVEMENT','REQUEST_SLOW_FALLING'])
        self.assertEqual(r['slow_falling_request'],dict(duration=10,amplifier=0,flags=[False]*3))

    def test_present_slow_falling_suppresses_request_only(self):
        f=dict(self.frames()[1],slow_falling_present=True)
        r=self.c.preview_frames([f])[0]
        self.assertEqual(r['velocity'],(4,-0.9,6)); self.assertIsNone(r['slow_falling_request'])
        self.assertEqual(r['actions'],['SET_MOVEMENT'])

    def test_nonpositive_duration_suppresses_all_actions_and_returns_false(self):
        for server in (True,False):
            for duration in (0,-1):
                with self.subTest(server=server,duration=duration):
                    f=dict(self.frames()[1],on_server=server,remaining_duration=duration)
                    r=self.c.preview_frames([f])[0]
                    self.assertEqual(r['velocity'],f['velocity']); self.assertEqual(r['actions'],[])
                    self.assertFalse(r['effect_tick_return']); self.assertIsNone(r['slow_falling_request'])

    def test_zero_y_and_custom_upward_factor(self):
        zero=dict(self.frames()[0],velocity=(1,0,3))
        r=self.c.preview_frames([zero,self.frames()[0]],upward_factor=0.5)
        self.assertEqual(r[0]['velocity'],(1,0.0,3)); self.assertIsNone(r[0]['slow_falling_request'])
        self.assertEqual(r[1]['velocity'],(1,1.0,3))

    def test_amplifier_owner_and_add_effect_result_do_not_gate_motion(self):
        a=dict(self.frames()[1],amplifier=0,owner=None,add_effect_accepted=False)
        b=dict(a,amplifier=7,owner='other',add_effect_accepted=True)
        self.assertEqual(self.c.preview_frames([a])[0],self.c.preview_frames([b])[0])

    def test_empty_trace_and_original_motion_unchanged(self):
        self.assertEqual(self.c.preview_frames([]),[])
        self.assertEqual(self.c.motion((1,2,3))['velocity'],(1,1.7,3))
        self.assertEqual(self.c.controller_query(0)['client_tick_ms'],200)
        self.assertEqual(self.c.attribute_amount(1),0.5)

    def test_trace_inputs_template_and_outputs_are_isolated(self):
        frames=[self.frames()[1],self.frames()[1]]; saved=copy.deepcopy(frames)
        template=copy.deepcopy(self.c.slow_fall); r=self.c.preview_frames(frames)
        self.assertEqual(frames,saved)
        r[0]['slow_falling_request']['flags'][0]=True
        self.assertEqual(r[1]['slow_falling_request']['flags'],[False]*3)
        self.assertEqual(self.c.slow_fall,template)
        self.assertEqual(self.c.preview_frames(frames)[0]['slow_falling_request'],template)

    def test_bad_policy_and_malformed_frame_fail_explicitly(self):
        for factor in (True,0,-1,float('nan'),float('inf'),'0.95'):
            with self.subTest(factor=factor),self.assertRaises(WorkflowError):
                self.c.preview_frames(self.frames(),upward_factor=factor)
        for frame in (None,dict(self.frames()[0],velocity=(1,2)),dict(self.frames()[0],velocity=(1,float('nan'),3))):
            with self.subTest(frame=frame),self.assertRaises(WorkflowError): self.c.preview_frames([frame])
'''

SPECS = {
1: '''Extend the existing single dropped-item preview into an ordered batch preview.
Add preview_items(state, items, *, heal_amount=6.0), returning {state, trace}.
Each trace entry retains deliver's existing output shape. Add optional heal_amount
to deliver with default 5.0 so existing calls remain unchanged. Preserve verified
maraca/remainder/foodstuffs/admission/dead-and-max-health semantics, consume one
per admitted callback, and carry state forward in order. Do not infer owner or
poison immunity. Validate finite positive numeric policy values (reject bool),
malformed item objects explicitly with ValueError, and preserve caller inputs
and independently owned trace/final snapshots. No Minecraft, AI scheduler or
item-stack system. Normalized consumed counts are fixture outputs, not native
event ordering. Verify the actual native literal and report static limits.''',
2: '''Extend the existing SugarRush controller fixture to preview an overridden
native duration request and an already selected existing local modifier.
Add request_preview(duration, *, request_multiplier=2.5, existing_modifier=None),
returning {operation, modifier, sync_existing_client}. New modifiers contain
max_duration, multiplier and radius. Refresh copies the supplied existing dict,
changes only max_duration and reports UPDATE_MAX_DURATION_ONLY, preserving all
other fields including nested metadata. New requests report ADD. Compute duration
using the same float32 multiplier as the native request, before ceil. Validate
positive integer durations within the fixture's recorded potion range and finite
positive float32-representable rates (reject bool) with WorkflowError. Existing
modifiers supplied by this scenario are valid; do not invent selection filters.
Extend controller_query with request_multiplier=None and existing_modifier=None;
None keeps original defaults. Query using the resulting stored multiplier/radius
and caller-supplied master_ticks. Preserve strict radius, expiry, owner validity,
recipient/config speed gates, double application of the local factor, unchanged
server GLOBAL query and flying-from-getSpeed behavior. Native refresh does not
reset age, replace rate/radius/dimension or sync existing client copies. Do not
build list selection, transport, hooks or a new controller. Verify Citadel pins
and the coupled literal's two uses. Preserve original properties/provenance.''',
3: '''Add SugarRush.preview_frames(frames, *, upward_factor=0.95) to the existing
motion fixture. Each independent frame supplies velocity, on_server,
remaining_duration and slow_falling_present. Return an ordered list of
{velocity, slow_falling_request, effect_tick_return, actions}. Positive-duration
server frames emit SET_MOVEMENT and, only on descending/absent Slow Falling,
REQUEST_SLOW_FALLING. Positive-duration client frames emit NATIVE_SOUND and keep
velocity. Nonpositive durations emit no actions and return false. Preserve X/Z,
downward factor, zero-Y ascending branch, original Slow Falling payload/flags,
ignored amplifier/owner/addEffect return, and independent input/template/result
snapshots. Validate finite positive policy values (reject bool), malformed frames
and nonfinite or wrong-length velocities explicitly with WorkflowError. Keep
existing motion/controller/attribute APIs and defaults unchanged. Do not implement
sound internals, hurt/owner logic or a game tick scheduler. Trace action names are
fixture markers, not proof of a new native event ordering. Verify native literal
and evidence, and preserve dependency and unresolved limits.'''
}
requests=['cockroach_heal','sugar_rush_dependency','sugar_rush_movement']
manifest=dict(commit=COMMIT,design='six fresh isolated agent contexts; matched paired coding fixtures',
    model='same inherited model for all arms; no overrides',reasoning='same inherited effort; no overrides',
    usage_telemetry=None,usage_limit='standalone Codex CLI authentication unavailable; agent usage telemetry not exposed',tasks={})
for task,test in [(1,TEST1),(2,TEST2),(3,TEST3)]:
    common=OUT/f'task{task}'
    common.mkdir(exist_ok=True)
    (common/'spec.txt').write_text(SPECS[task])
    request=SOURCE/f'scripts/external-effects/examples/change_requests/{requests[task-1]}.json'
    # The request proposes only the native numeric change; coding requirements
    # include adapter work and preserve behavior outside that literal footprint.
    starter=ROACH if task==1 else (SOURCE/'scripts/external-effects/examples/sugar_rush_workflow.py').read_text().replace(
        "CLI = Path(__file__).resolve().parents[1] / 'mod_intelligence.py'",f'CLI = Path({str(CLI)!r})')
    for arm in ('A','B'):
        work=common/arm; work.mkdir(exist_ok=True)
        (work/'solution.py').write_text(starter)
        (work/'test_acceptance.py').write_text(test)
        (work/'spec.txt').write_text(SPECS[task])
        shutil.copyfile(request,work/'request.json')
        if task!=1:
            legacy=(SOURCE/'scripts/external-effects/test_mod_intelligence_workflow.py').read_text()
            # Identical importer substitution in both arms; assertions untouched.
            (work/'test_legacy.py').write_text(legacy.replace('from examples.sugar_rush_workflow import','from solution import'))
        files={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in work.iterdir() if p.is_file()}
        manifest['tasks'].setdefault(str(task),{})[arm]=files
    if manifest['tasks'][str(task)]['A'] != manifest['tasks'][str(task)]['B']:
        raise RuntimeError('Unmatched initial arm files')
(OUT/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps({'frozen_commit':COMMIT,'matched_tasks':3,'matched_arms':6,'source_cli':str(CLI)}))
