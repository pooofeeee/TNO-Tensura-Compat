"""Independent post-run scoring; does not repair either solution."""
import ast
from collections import Counter
import datetime
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import sys

BASE=Path(__file__).resolve().parent
manifest=json.loads((BASE/'manifest.json').read_text())
results={}
for task in (1,2,3):
    results[str(task)]={}
    for arm in ('A','B'):
        work=BASE/f'task{task}/{arm}'
        if not (work/'agent_report.json').exists():
            raise RuntimeError(f'Run not finished: {task}/{arm}')
        events=[json.loads(s) for s in (work/'events.jsonl').read_text().splitlines()]
        counts=Counter(e['operation'] for e in events)
        inspected=set(f for e in events for f in e.get('files_inspected',[]))
        searched_paths=set(p for e in events for p in e.get('searched_paths',[]))
        catalog_inputs=set(i['file'] for e in events for i in e.get('catalog_inputs',[]))
        initial=manifest['tasks'][str(task)][arm]
        changed=[]
        for file,sha in initial.items():
            current=hashlib.sha256((work/file).read_bytes()).hexdigest()
            if current!=sha: changed.append(file)
        if set(changed)-{'solution.py'}:
            raise RuntimeError(f'Frozen input modified: {task}/{arm}/{changed}')
        validation={}
        for mode,flags,opt in [('normal',[],'0'),('optimized',['-O'],'0'),('environment',[],'1')]:
            cmd=[sys.executable,'-B',*flags,'-m','unittest','discover','-s',str(work),'-p','test*.py','-q']
            p=subprocess.run(cmd,capture_output=True,text=True,
                env=dict(os.environ,PYTHONOPTIMIZE=opt,PYTHONDONTWRITEBYTECODE='1'))
            text=p.stdout+p.stderr
            (work/f'independent-{mode}.log').write_text(text)
            match=re.search(r'Ran (\d+) tests',text)
            validation[mode]={'exit':p.returncode,'tests':int(match[1]) if match else None,'pass':p.returncode==0}
        start=datetime.datetime.fromisoformat(events[0]['utc'])
        finish_event=next(e for e in reversed(events) if e['operation']=='finish')
        finish=datetime.datetime.fromisoformat(finish_event['utc'])+datetime.timedelta(seconds=finish_event['elapsed_seconds'])
        failed_tests=[e['index'] for e in events if e['operation']=='test' and e['exit']!=0]
        failed_operations=[e['index'] for e in events if e['exit']!=0
                           and not (e['operation']=='search' and e['exit']==1)]
        first_edit=min((e['index'] for e in events if e['operation']=='edit' and e['exit']==0),default=None)
        implementation_batches=sum(e['operation']=='edit' and e['exit']==0 for e in events)
        fixes_after_failure=sum(e['operation']=='edit' and e['exit']==0 and any(f<e['index'] for f in failed_tests) for e in events)
        commands=[dict(index=e['index'],operation=e['operation'],arguments=e['arguments'],command=e.get('command'),exit=e['exit']) for e in events]
        cli_schemas=[e.get('schema') for e in events if e['operation']=='cli']
        report=json.loads((work/'agent_report.json').read_text())
        results[str(task)][arm]={
            'files_inspected':len(inspected),'file_paths':sorted(inspected),
            'searched_paths':sorted(searched_paths),'searches':counts['search'],
            'tool_operations':len(events),'nested_exec_command_calls':len(events),
            'meter_commands':len(events),'subprocess_commands':sum('command' in e for e in events),
            'cli_commands':counts['cli'],'cli_schemas':cli_schemas,
            'catalog_inputs_read_by_cli':len(catalog_inputs),
            'test_commands_during_coding':counts['test'],
            'failed_test_runs':len(failed_tests),'failed_operations':len(failed_operations),
            'failed_operation_indices':failed_operations,
            'successful_edit_batches':implementation_batches,'edits_after_test_failure':fixes_after_failure,
            'corrections_reported':report.get('corrections'),
            'non_meter_tool_calls_reported':report.get('non_meter_tool_calls'),
            'elapsed_seconds':round((finish-start).total_seconds(),3),
            'tool_execution_seconds':round(sum(e['elapsed_seconds'] for e in events),3),
            'emitted_stdout_characters':sum(e['displayed_characters'] for e in events),
            'raw_command_output_bytes':sum(e['output_bytes'] for e in events),
            'display_limits':sum(bool(e.get('output_limited')) for e in events),
            'usage_telemetry':None,'usage_savings_claim':False,
            'independent_validation':validation,'frozen_tests_unchanged':True,
            'solution_sha256':hashlib.sha256((work/'solution.py').read_bytes()).hexdigest(),
            'restoration_needed':report.get('restoration_needed'),
            'unknowns':report.get('unknowns'), 'commands':commands}
        print(json.dumps({'task':task,'arm':arm,'operations':len(events),'cli':counts['cli'],
            'elapsed':results[str(task)][arm]['elapsed_seconds'],'validation':validation}),flush=True)
(BASE/'results.json').write_text(json.dumps(results,indent=2)+'\n')
