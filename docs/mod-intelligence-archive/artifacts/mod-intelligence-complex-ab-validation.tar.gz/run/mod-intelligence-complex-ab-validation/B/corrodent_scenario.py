"""Experimental bite requests and animation protocol; explicit caller phases."""
from dataclasses import dataclass
import json
import math
from pathlib import Path
import struct

from animation_events import Animation, State, advance, receive_animation


@dataclass(frozen=True)
class Contract:
    bite_duration: int
    bite_tick: int
    attack_attribute: float
    bite_multiplier: float
    vehicle_fraction: float
    knockback_base: float
    knockback_multiplier: float
    clock_increment: int
    provenance: dict


@dataclass(frozen=True)
class Target:
    distance: float = 1.0
    width: float = 0.5
    line_of_sight: bool = True
    hurt_accepted: bool = False
    vehicle: bool = False
    vehicle_hurt_accepted: bool = False
    position_xz: tuple = (1.0, 2.0)
    post_knockback_velocity: tuple = (0.1, 0.2, 0.3)


def load_contract(path=Path(__file__).with_name('contract.json')):
    def nonfinite(value):
        raise ValueError('Nonfinite contract number: ' + value)
    raw = json.loads(Path(path).read_text(), parse_constant=nonfinite)
    pins = {'schema': 'experiment.corrodent_contract.v1', 'mod_version': '2.0.10',
        'mod_sha256': '6fad35bf07fcb977aaa32d3fe05bf122150c6a30ed16b057385040207a3b788f',
        'dependency_version': '2.7.6',
        'dependency_sha256': '9e12468c49e5a95b7adbf22b3b4d05bc55565989b89c40b985cd73bdfe63c3c2'}
    if not isinstance(raw, dict) or any(raw.get(key) != value for key, value in pins.items()):
        raise ValueError('Invalid schema or source identity')
    numbers = ('bite_duration', 'bite_tick', 'attack_attribute', 'bite_multiplier',
               'vehicle_fraction', 'knockback_base', 'knockback_multiplier', 'clock_increment')
    for key in numbers:
        value = raw.get(key)
        if type(value) not in (int, float) or not math.isfinite(value):
            raise ValueError('Missing or nonfinite value: ' + key)
    for key in ('bite_duration', 'bite_tick', 'clock_increment'):
        if type(raw[key]) is not int or raw[key] <= 0:
            raise ValueError('Expected positive integer: ' + key)
    if not isinstance(raw.get('provenance'), dict):
        raise ValueError('Missing provenance')
    return Contract(**{key: raw[key] for key in numbers}, provenance=raw['provenance'])


def float32(value):
    return struct.unpack('f', struct.pack('f', value))[0]


class CorrodentPreview:
    def __init__(self, contract):
        self.contract = contract
        self.bite = Animation('BITE', contract.bite_duration)
        self.registry = (self.bite,)
        self.state = State(self.bite)
        self.burrowing = False

    def clock(self, *, server=True, on_start=None, on_tick=None):
        return advance(self.state, self.registry, increment=self.contract.clock_increment,
                       server=server, on_start=on_start, on_tick=on_tick)

    def goal(self, target, *, actor_width=0.5, actor_position_xz=(4.0, 5.0), attack_attribute=None):
        if self.state.animation is not self.bite or self.state.tick != self.contract.bite_tick or target is None:
            return []
        reach = float32(float32(actor_width) + float32(target.width)) + 1.0
        if not target.line_of_sight or float32(target.distance) >= reach:
            return []
        damage_attribute = self.contract.attack_attribute if attack_attribute is None else attack_attribute
        multiplier = float32(self.contract.bite_multiplier)
        amount = float32(float32(damage_attribute) * multiplier)
        effects = [{'action': 'HURT_VICTIM', 'amount': amount, 'accepted': target.hurt_accepted},
            {'action': 'KNOCKBACK', 'strength': self.contract.knockback_base +
                self.contract.knockback_multiplier * multiplier,
             'direction_xz': tuple(actor - victim for actor, victim in zip(actor_position_xz, target.position_xz))}]
        if target.vehicle:
            effects.append({'action': 'COPY_POST_KNOCKBACK_VELOCITY', 'velocity': target.post_knockback_velocity})
            effects.append({'action': 'HURT_VEHICLE',
                'amount': float32(amount * float32(self.contract.vehicle_fraction)),
                'accepted': target.vehicle_hurt_accepted})
        self.burrowing = True
        return effects

    def packet(self, index):
        receive_animation(self.state, index, self.registry)
