"""Experimental Citadel animation adapter; scenario callbacks, no game runtime."""
from dataclasses import dataclass


@dataclass(frozen=True, eq=False)
class Animation:
    name: str
    duration: int


NO_ANIMATION = Animation('NO_ANIMATION', 0)


@dataclass
class State:
    animation: Animation | None
    tick: int = 0


@dataclass
class Start:
    animation: Animation
    cancelled: bool = False


def send_animation(state, animation, registry, *, server=True):
    if not server:
        return []
    state.animation = animation
    index = -1
    for position, candidate in enumerate(registry):
        if candidate is animation:
            index = position
            break
    return [dict(action='SEND_ANIMATION', index=index)]


def receive_animation(state, index, registry):
    if index == -1:
        state.animation = NO_ANIMATION
    else:
        if index < 0 or index >= len(registry):
            raise IndexError('Animation packet index outside registry')
        state.animation = registry[index]
    state.tick = 0


def advance(state, registry, *, increment=1, server=True, on_start=None, on_tick=None):
    if state.animation is None:
        state.animation = NO_ANIMATION
    trace = []
    if state.animation is not NO_ANIMATION and state.tick == 0:
        start = Start(state.animation)
        if on_start is not None:
            on_start(start)
        trace.append({'action': 'POST_START', 'cancelled': start.cancelled})
        if not start.cancelled:
            trace += send_animation(state, start.animation, registry, server=server)
    if state.tick < state.animation.duration:
        state.tick += increment
        trace.append({'action': 'POST_TICK', 'tick': state.tick})
        if on_tick is not None:
            on_tick(state)
    # Current actor state, not the pre-event animation/duration snapshot.
    if state.tick == state.animation.duration:
        state.tick, state.animation = 0, NO_ANIMATION
        trace.append({'action': 'RESET_TO_NO_ANIMATION'})
    return trace
