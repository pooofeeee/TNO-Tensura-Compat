"""Experimental Citadel animation adapter; scenario callbacks, no game runtime."""
from dataclasses import dataclass


@dataclass(frozen=True, eq=False)
class Animation:
    name: str
    duration: int


NO_ANIMATION = Animation('NO_ANIMATION', 0)


@dataclass
class State:
    animation: Animation | None
    tick: int = 0


@dataclass
class Start:
    animation: Animation
    cancelled: bool = False


def send_animation(state, animation, registry, *, server=True):
    if not server:
        return []
    # Corrodent.setAnimation assigns the object without resetting its tick.
    state.animation = animation
    index = next((i for i, value in enumerate(registry) if value is animation), -1)
    return [dict(action='SEND_ANIMATION', index=index)]


def receive_animation(state, index, registry):
    if index != -1 and not 0 <= index < len(registry):
        raise IndexError('Animation packet index outside registry')
    state.animation = NO_ANIMATION if index == -1 else registry[index]
    state.tick = 0


def advance(state, registry, *, increment=1, server=True, on_start=None, on_tick=None):
    actions = []
    if state.animation is None:
        state.animation = NO_ANIMATION
    if state.animation is not NO_ANIMATION and state.tick == 0:
        event = Start(state.animation)
        if on_start:
            on_start(event)
        actions.append(dict(action='POST_START', cancelled=event.cancelled))
        if not event.cancelled:
            actions.extend(send_animation(state, event.animation, registry, server=server))
    if state.tick < state.animation.duration:
        state.tick += increment
        actions.append(dict(action='POST_TICK', tick=state.tick))
        if on_tick:
            on_tick(state)
    # The native handler re-reads both values after the Tick listener.
    if state.tick == state.animation.duration:
        state.tick = 0
        state.animation = NO_ANIMATION
        actions.append(dict(action='RESET_TO_NO_ANIMATION'))
    return actions
