"""Exercise the extension with explicit phase and observed target inputs."""
import json

from animation_events import Animation
from corrodent_scenario import CorrodentPreview, Target, load_contract


def trace(preview, target, updates, **listeners):
    output = []
    for _ in range(updates):
        before = dict(animation=preview.state.animation.name, tick=preview.state.tick)
        goals = preview.goal(target)
        clock = preview.clock(**listeners)
        output.append(dict(before=before, goal_actions=goals, clock_actions=clock,
            after=dict(animation=preview.state.animation.name, tick=preview.state.tick)))
    return output


contract = load_contract()
normal = CorrodentPreview(contract)
normal.state.tick = 6
cancelled = CorrodentPreview(contract)
replaced = CorrodentPreview(contract)
other = Animation('OTHER', 2)
print(json.dumps(dict(scope='STATIC_EXPLICIT_GOAL_BEFORE_CLOCK_SCENARIOS',
    rejected_hurt_and_vehicle=trace(normal, Target(vehicle=True), 11),
    cancelled_start=trace(cancelled, Target(), 2, on_start=lambda event: setattr(event, 'cancelled', True)),
    start_replacement=trace(replaced, Target(), 2, on_start=lambda event: setattr(event, 'animation', other))),
    sort_keys=True, separators=(',', ':'), allow_nan=False))
