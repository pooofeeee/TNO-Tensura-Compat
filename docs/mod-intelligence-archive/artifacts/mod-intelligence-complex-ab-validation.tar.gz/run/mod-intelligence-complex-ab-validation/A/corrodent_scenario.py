"""Experimental bite requests and animation protocol; explicit caller phases."""
from dataclasses import dataclass
import json
import math
from pathlib import Path
import struct

from animation_events import Animation, State, advance, receive_animation


@dataclass(frozen=True)
class Contract:
    bite_duration: int
    bite_tick: int
    attack_attribute: float
    bite_multiplier: float
    vehicle_fraction: float
    knockback_base: float
    knockback_multiplier: float
    clock_increment: int
    provenance: dict


@dataclass(frozen=True)
class Target:
    distance: float = 1.0
    width: float = 0.5
    line_of_sight: bool = True
    hurt_accepted: bool = False
    vehicle: bool = False
    vehicle_hurt_accepted: bool = False
    position_xz: tuple = (1.0, 2.0)
    post_knockback_velocity: tuple = (0.1, 0.2, 0.3)


def load_contract(path=Path(__file__).with_name('contract.json')):
    def reject(value):
        raise ValueError('Nonfinite contract number: ' + value)
    data = json.loads(Path(path).read_text(), parse_constant=reject)
    expected = {'schema': 'experiment.corrodent_contract.v1', 'mod_version': '2.0.10',
        'mod_sha256': '6fad35bf07fcb977aaa32d3fe05bf122150c6a30ed16b057385040207a3b788f',
        'dependency_version': '2.7.6',
        'dependency_sha256': '9e12468c49e5a95b7adbf22b3b4d05bc55565989b89c40b985cd73bdfe63c3c2'}
    if not isinstance(data, dict) or any(data.get(k) != v for k, v in expected.items()):
        raise ValueError('Stale or unsupported contract')
    fields = list(Contract.__dataclass_fields__)
    for name in fields[:-1]:
        value = data.get(name)
        if type(value) not in (int, float) or not math.isfinite(value):
            raise ValueError('Missing or nonfinite parameter: ' + name)
    for name in ('bite_duration', 'bite_tick', 'clock_increment'):
        if type(data[name]) is not int or data[name] <= 0:
            raise ValueError('Expected positive integer: ' + name)
    if not isinstance(data.get('provenance'), dict):
        raise ValueError('Missing provenance')
    return Contract(**{name: data[name] for name in fields})


def float32(value):
    return struct.unpack('f', struct.pack('f', value))[0]


class CorrodentPreview:
    def __init__(self, contract):
        self.contract = contract
        self.bite = Animation('BITE', contract.bite_duration)
        self.registry = (self.bite,)
        self.state = State(self.bite)
        self.burrowing = False

    def clock(self, *, server=True, on_start=None, on_tick=None):
        return advance(self.state, self.registry, increment=self.contract.clock_increment,
                       server=server, on_start=on_start, on_tick=on_tick)

    def goal(self, target, *, actor_width=0.5, actor_position_xz=(4.0, 5.0), attack_attribute=None):
        if target is None or self.state.animation is not self.bite or self.state.tick != self.contract.bite_tick:
            return []
        width_sum = float32(float32(actor_width) + float32(target.width))
        if not target.line_of_sight or float32(target.distance) >= width_sum + 1.0:
            return []
        attribute = self.contract.attack_attribute if attack_attribute is None else attack_attribute
        multiplier = float32(self.contract.bite_multiplier)
        amount = float32(float32(attribute) * multiplier)
        direction = tuple(a - b for a, b in zip(actor_position_xz, target.position_xz))
        actions = [dict(action='HURT_VICTIM', amount=amount, accepted=target.hurt_accepted),
                   dict(action='KNOCKBACK', strength=self.contract.knockback_base +
                        self.contract.knockback_multiplier * multiplier, direction_xz=direction)]
        if target.vehicle:
            actions.extend([dict(action='COPY_POST_KNOCKBACK_VELOCITY', velocity=target.post_knockback_velocity),
                dict(action='HURT_VEHICLE', amount=float32(amount * float32(self.contract.vehicle_fraction)),
                     accepted=target.vehicle_hurt_accepted)])
        self.burrowing = True
        return actions

    def packet(self, index):
        receive_animation(self.state, index, self.registry)
