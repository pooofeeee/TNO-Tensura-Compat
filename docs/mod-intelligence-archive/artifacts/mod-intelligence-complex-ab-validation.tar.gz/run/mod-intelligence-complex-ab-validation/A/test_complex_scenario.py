"""Frozen contract oracle: native caller plus dependency semantics, no CLI calls."""
import copy
import json
from pathlib import Path
import tempfile
import unittest

from animation_events import Animation, NO_ANIMATION, send_animation
from corrodent_scenario import CorrodentPreview, Target, load_contract


class ComplexScenarioTests(unittest.TestCase):
    def setUp(self):
        self.contract = load_contract()
        self.preview = CorrodentPreview(self.contract)

    def test_cancelled_start_advances_without_packet_or_replacement(self):
        other = Animation('OTHER', 2)
        def cancel(event):
            event.animation, event.cancelled = other, True
        actions = self.preview.clock(on_start=cancel)
        self.assertIs(self.preview.state.animation, self.preview.bite)
        self.assertEqual(self.preview.state.tick, 1)
        self.assertEqual([a['action'] for a in actions], ['POST_START', 'POST_TICK'])
        self.assertTrue(actions[0]['cancelled'])

    def test_server_start_replacement_changes_clock_and_unregistered_index(self):
        other = Animation('OTHER', 2)
        actions = self.preview.clock(on_start=lambda e: setattr(e, 'animation', other))
        self.assertIs(self.preview.state.animation, other)
        self.assertEqual(self.preview.state.tick, 1)
        self.assertEqual(actions[1], dict(action='SEND_ANIMATION', index=-1))
        self.assertEqual(self.preview.goal(Target()), [])

    def test_client_start_replacement_does_not_change_local_animation(self):
        other = Animation('OTHER', 2)
        actions = self.preview.clock(server=False, on_start=lambda e: setattr(e, 'animation', other))
        self.assertIs(self.preview.state.animation, self.preview.bite)
        self.assertEqual(self.preview.state.tick, 1)
        self.assertEqual([a['action'] for a in actions], ['POST_START', 'POST_TICK'])

    def test_tick_listener_changes_animation_before_terminal_comparison(self):
        self.preview.state.tick = 14
        other = Animation('OTHER', 3)
        def mutate(state):
            state.animation, state.tick = other, 1
        actions = self.preview.clock(on_tick=mutate)
        self.assertEqual(actions, [dict(action='POST_TICK', tick=15)])
        self.assertIs(self.preview.state.animation, other)
        self.assertEqual(self.preview.state.tick, 1)

    def test_tick_listener_can_move_clock_to_equality(self):
        self.preview.state.tick = 7
        actions = self.preview.clock(on_tick=lambda state: setattr(state, 'tick', 15))
        self.assertEqual([a['action'] for a in actions], ['POST_TICK', 'RESET_TO_NO_ANIMATION'])
        self.assertIs(self.preview.state.animation, NO_ANIMATION)
        self.assertEqual(self.preview.state.tick, 0)

    def test_tick_listener_overshoot_is_not_reset(self):
        self.preview.state.tick = 14
        actions = self.preview.clock(on_tick=lambda state: setattr(state, 'tick', 16))
        self.assertEqual(actions, [dict(action='POST_TICK', tick=15)])
        self.assertEqual(self.preview.state.tick, 16)
        self.assertIs(self.preview.state.animation, self.preview.bite)

    def test_terminal_tick_is_posted_before_exact_equality_reset(self):
        self.preview.state.tick = 14
        self.assertEqual(self.preview.clock(), [dict(action='POST_TICK', tick=15),
            dict(action='RESET_TO_NO_ANIMATION')])
        self.assertEqual(self.preview.state.tick, 0)
        self.assertIs(self.preview.state.animation, NO_ANIMATION)

    def test_zero_duration_above_duration_and_null_are_distinct(self):
        self.preview.state.animation = Animation('ZERO', 0)
        actions = self.preview.clock()
        self.assertEqual([a['action'] for a in actions], ['POST_START', 'SEND_ANIMATION', 'RESET_TO_NO_ANIMATION'])
        self.preview.state.animation, self.preview.state.tick = self.preview.bite, 16
        self.assertEqual(self.preview.clock(), [])
        self.assertEqual(self.preview.state.tick, 16)
        self.preview.state.animation, self.preview.state.tick = None, 0
        self.preview.clock()
        self.assertIs(self.preview.state.animation, NO_ANIMATION)

    def test_native_setter_preserves_tick_but_client_packet_restarts(self):
        self.preview.state.tick = 8
        self.assertEqual(send_animation(self.preview.state, self.preview.bite, self.preview.registry),
                         [dict(action='SEND_ANIMATION', index=0)])
        self.assertEqual(self.preview.state.tick, 8)
        self.preview.packet(0)
        self.assertIs(self.preview.state.animation, self.preview.bite)
        self.assertEqual(self.preview.state.tick, 0)
        self.preview.packet(-1)
        self.assertIs(self.preview.state.animation, NO_ANIMATION)

    def test_bite_requires_exact_frame_and_native_animation_identity(self):
        for tick in (0, 7, 9, 15):
            self.preview.state.tick = tick
            self.assertEqual(self.preview.goal(Target()), [])
        self.preview.state.tick = 8
        self.preview.state.animation = Animation('BITE', 15)
        self.assertEqual(self.preview.goal(Target()), [])
        self.preview.state.animation = self.preview.bite
        self.assertEqual(self.preview.goal(Target())[0]['amount'], 4.5)

    def test_line_of_sight_target_and_strict_float_width_range(self):
        self.preview.state.tick = 8
        for target in (None, Target(line_of_sight=False), Target(distance=2.0), Target(distance=2.1)):
            self.assertEqual(self.preview.goal(target), [])
        self.assertEqual(self.preview.goal(Target(distance=1.99))[0]['amount'], 4.5)

    def test_rejected_victim_hurt_still_knocks_vehicle_and_sets_burrowing(self):
        self.preview.state.tick = 8
        actions = self.preview.goal(Target(vehicle=True, hurt_accepted=False))
        self.assertEqual([a['action'] for a in actions], ['HURT_VICTIM', 'KNOCKBACK',
            'COPY_POST_KNOCKBACK_VELOCITY', 'HURT_VEHICLE'])
        self.assertEqual(actions[0]['amount'], 4.5)
        self.assertFalse(actions[0]['accepted'])
        self.assertAlmostEqual(actions[1]['strength'], 0.65)
        self.assertEqual(actions[1]['direction_xz'], (3.0, 3.0))
        self.assertEqual(actions[2]['velocity'], (0.1, 0.2, 0.3))
        self.assertEqual(actions[3]['amount'], 2.25)
        self.assertTrue(self.preview.burrowing)

    def test_live_attribute_override_changes_requests_not_knockback(self):
        self.preview.state.tick = 8
        actions = self.preview.goal(Target(vehicle=True, hurt_accepted=True), attack_attribute=6.0)
        self.assertEqual(actions[0]['amount'], 9.0)
        self.assertEqual(actions[3]['amount'], 4.5)
        self.assertAlmostEqual(actions[1]['strength'], 0.65)

    def test_stale_pins_wrong_schema_and_nonfinite_contracts_fail(self):
        original = json.loads(Path('contract.json').read_text())
        for field, value in [('mod_sha256', 'f' * 64), ('dependency_version', '2.7.7'),
                             ('schema', 'unknown'), ('bite_multiplier', float('nan'))]:
            bad = copy.deepcopy(original)
            bad[field] = value
            with tempfile.TemporaryDirectory() as directory:
                path = Path(directory) / 'contract.json'
                path.write_text(json.dumps(bad))
                with self.assertRaises(ValueError):
                    load_contract(path)

    def test_explicit_goal_before_clock_trace_has_one_bite_and_then_ends(self):
        self.preview.state.tick = 6
        trace = []
        for _ in range(11):
            trace.extend(self.preview.goal(Target(vehicle=True)))
            trace.extend(self.preview.clock())
        hits = [a for a in trace if a['action'] == 'HURT_VICTIM']
        self.assertEqual([a['amount'] for a in hits], [4.5])
        self.assertIs(self.preview.state.animation, NO_ANIMATION)
        self.assertEqual(self.preview.state.tick, 0)


if __name__ == '__main__':
    unittest.main()
