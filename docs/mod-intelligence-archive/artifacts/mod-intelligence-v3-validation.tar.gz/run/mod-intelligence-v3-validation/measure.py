import ast
import hashlib
import json
from pathlib import Path
import subprocess
import sys

ROOT = Path.cwd()
RUN = ROOT / 'run/mod-intelligence-v3-validation'
CLI = ROOT / 'scripts/external-effects/mod_intelligence.py'
sys.path.insert(0, str(CLI.parent))
import mod_intelligence as mi
import test_mod_intelligence_v3 as tests

def retrieve(arguments, output):
    result = subprocess.run([sys.executable, '-B', str(CLI), *arguments], capture_output=True, check=True)
    (RUN / output).write_bytes(result.stdout)
    response = json.loads(result.stdout)
    if response['status'] != 'OK':
        raise ValueError(response)
    return response['data'], len(result.stdout)

examples = []
versions = {'alexsmobs': '1.22.17', 'alexscaves': '2.0.10', 'royalvariations': '2.0'}
for file in sorted((CLI.parent/'examples/change_requests').glob('*.json')):
    request = json.loads(file.read_text())
    identity = request['target']
    mod = identity.split(':')[0]
    flags = ['--expect-version', versions[mod]]
    if mod == 'alexscaves':
        flags += ['--expect-dependency-version', '2.7.6', '--expect-dependency-sha256',
                  '9e12468c49e5a95b7adbf22b3b4d05bc55565989b89c40b985cd73bdfe63c3c2']
    impact, impact_bytes = retrieve(['impact', identity, '--limit', '100', *flags], file.stem+'-impact.json')
    context, context_bytes = retrieve(['context', identity, '--budget-bytes', '1000000', *flags], file.stem+'-context.json')
    plan, plan_bytes = retrieve(['plan', '--request', str(file.relative_to(ROOT)), *flags], file.stem+'-plan.json')
    expected_components = {(g['mechanic_id'], i): c for g in context['numbers_and_formulas'] for i, c in enumerate(g['components'])}
    actual_components = {(r['mechanic_id'], r['component_index']): r['record'] for r in plan['preserved_constraints'] if r['kind'] == 'RECORDED_COMPONENT'}
    expected_contracts = {b['id']: {k: v for k, v in b.items() if k not in ('id', 'actual_behavior', 'relationship')} for b in context['verified_behavior']}
    actual_contracts = {r['mechanic_id']: r['record'] for r in plan['preserved_constraints'] if r['kind'] == 'RECORDED_CONTRACT'}
    expected_observations = {g['mechanic_id']: g['observations'] for g in context['numbers_and_formulas']}
    actual_observations = {r['mechanic_id']: r['record'] for r in plan['preserved_constraints'] if r['kind'] == 'RECORDED_NUMERIC_OBSERVATIONS'}
    expected_deliveries = {g['mechanic_id']: g['paths'] for g in context['delivery_paths']}
    actual_deliveries = {r['mechanic_id']: r['record'] for r in plan['preserved_constraints'] if r['kind'] == 'RECORDED_DELIVERY'}
    expected_dependencies = [{k: v for k, v in d.items() if k != 'relationship'} for d in context['dependencies']]
    actual_dependencies = [d['record'] for d in plan['dependencies']]
    comparisons = [expected_components == actual_components, expected_contracts == actual_contracts,
                   expected_observations == actual_observations, expected_deliveries == actual_deliveries,
                   expected_dependencies == actual_dependencies]
    if not all(comparisons):
        raise ValueError('Required constraint projection differs: '+file.stem)
    sites = [s for s in plan['source_locations'] if s['kind'] == 'CURRENT_LITERAL_SITE']
    site_methods = {(s['file'], s['entry'], s['method'], s['descriptor']) for s in sites}
    kinds = [q['kind'] for q in plan['risks_and_questions']]
    metric = dict(example=file.stem, target=identity, readiness=plan['readiness'],
        impact_bytes=impact_bytes, context_bytes=context_bytes, plan_bytes=plan_bytes,
        impact_methods=len(impact['confirmed_contract']['methods']), selected_methods=len(site_methods),
        omitted_method_records=plan['projection']['omitted_method_records'],
        omitted_unselected_numeric_consumers=plan['projection']['omitted_unselected_numeric_consumers'],
        broad_peer_candidates=impact['possible_impact']['total'],
        conditional_shared_method_items=kinds.count('CONDITIONAL_SHARED_METHOD'),
        missing_recorded_constraint_groups=0, retained_components=len(actual_components),
        recorded_obligations=len(actual_dependencies), literal_sites=len(sites),
        shared_consumer_warnings=kinds.count('SHARED_CONSUMER_METHOD'),
        unresolved_literal_binding='NUMERIC_LITERAL_SITE' in kinds,
        unresolved_dependency_mapping='DEPENDENCY_MAPPING' in kinds,
        current_values=[s['literal']['current_value'] for s in sites],
        source_checks=dict(native=plan['source_check'], dependencies=[d['record']['source_check'] for d in plan['dependencies']]),
        repository_inputs=plan['repository_inputs'])
    examples.append(metric)
    print(json.dumps({k: metric[k] for k in ('example','readiness','impact_bytes','context_bytes','plan_bytes','omitted_method_records','literal_sites')}, separators=(',',':')))

probe = tests.ChangePlanTests(methodName='runTest')
probe.setUp()
try:
    probe.fixture.peer('demo:shared', dict(probe.f.proof))
    probe.fixture.peer('demo:name_only', dict(probe.f.proof, entry='Other.class'))
    probe.fixture.peer('demo:other_packet', dict(probe.f.proof, evidence_file='absent.json'))
    probe.fixture.peer('demo:overload', dict(probe.f.proof, descriptor='(I)V'))
    probe.links, probe.document = probe.fixture.mapping()
    result = probe.plan()
    peers = [i for i in result['risks_and_questions'] if i['kind'] == 'CONDITIONAL_SHARED_METHOD']
    if [i['mechanic_id'] for i in peers] != ['demo:shared']:
        raise ValueError('Unexpected conditional peer')
    false_positives = dict(negative_candidates=3, false_edges=0, positive_controls=1,
        positive_classification=peers[0]['classification'], global_rate='NOT_ESTABLISHED')
finally:
    probe.doCleanups()

module = (CLI.parent/'mod_intelligence_plan.py').read_text()
core_delta = subprocess.check_output(['git','diff','--numstat','HEAD','--',str(CLI.relative_to(ROOT))], text=True).split()
summary = dict(examples=examples, false_positive_probe=false_positives,
    complexity=dict(new_engine_physical_lines=len(module.splitlines()),
        new_engine_functions=sum(isinstance(n, ast.FunctionDef) for n in ast.parse(module).body),
        core_added_lines=int(core_delta[0]), core_removed_lines=int(core_delta[1]), new_package_dependencies=0),
    usage_savings='NOT_MEASURED', omission_meaning='Omitted detail is not proof of no impact.',
    preservation_measure='Exact comparison of root components, contract/gates/facts, numeric observations, delivery records and selected dependency contracts.')
(RUN/'measurements.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps({'false_positive_probe': false_positives,'complexity':summary['complexity']},separators=(',',':')))
