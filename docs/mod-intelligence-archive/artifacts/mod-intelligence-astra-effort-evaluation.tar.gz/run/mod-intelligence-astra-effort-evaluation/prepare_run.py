"""Create new result workspaces from unchanged, hash-locked benchmark inputs."""
import ast
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import sys

ROOT=Path('/workspace/mod-intelligence-v1')
PRIOR=ROOT/'run/mod-intelligence-real-coding-benchmark'
OUT=Path(__file__).resolve().parent
old=json.loads((PRIOR/'manifest.json').read_text())
COMMIT='e0918e782355756f718a1adcff1f346a26230327'
if subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()!=COMMIT:
    raise RuntimeError('Repository differs from requested commit')

def digest(path): return hashlib.sha256(path.read_bytes()).hexdigest()
protected={p.relative_to(PRIOR).as_posix():digest(p) for p in PRIOR.rglob('*')
           if p.is_file() and not p.is_symlink()}
(OUT/'prior-artifact-hashes.json').write_text(json.dumps(protected,indent=2)+'\n')
# The meter is unchanged. Its BASE follows this copy's location; its own-arm
# whitelist and all measurements/operation semantics remain identical.
shutil.copyfile(PRIOR/'meter.py',OUT/'meter.py')
shutil.copytree(PRIOR/'source',OUT/'source',symlinks=True)

tree=ast.parse((PRIOR/'prepare.py').read_text())
roach=next(ast.literal_eval(n.value) for n in tree.body if isinstance(n,ast.Assign)
           and any(isinstance(t,ast.Name) and t.id=='ROACH' for t in n.targets))
old_cli=PRIOR/'source/scripts/external-effects/mod_intelligence.py'
sugar=(PRIOR/'source/scripts/external-effects/examples/sugar_rush_workflow.py').read_text().replace(
    "CLI = Path(__file__).resolve().parents[1] / 'mod_intelligence.py'",f'CLI = Path({str(old_cli)!r})')
manifest=dict(commit=COMMIT,model_requested='gpt-6-astra',reasoning_requested='xhigh',
    baseline_model_user_identification='GPT-6 Astra Medium',
    baseline_model_record='gpt-6-astra / medium requested in prior manifest',
    baseline_workflow='completed Astra Medium B arms: V4 plus permitted V3/V1 restoration',
    meter_sha256=digest(OUT/'meter.py'),source='byte-identical copy of prior committed source export',
    protected_prior_artifacts=len(protected),tasks={},usage_telemetry=None,
    controls={'fresh_contexts':True,'no_solutions_in_prompts':True,'unchanged_tests':True,
              'same_success_criteria':True,'no_reasoning_escalation_planned':True,
              'source_pins_unchanged':True,'same_meter_code':True},
    elapsed_definition='first metered operation start to finish completion; same as prior',
    context_measurement='emitted tool stdout characters/bytes only; complete model context and token telemetry unavailable')
for task in (1,2,3):
    work=OUT/f'task{task}/B'; work.mkdir(parents=True)
    for file,sha in old['tasks'][str(task)]['B'].items():
        path=work/file
        if file=='solution.py': path.write_text(roach if task==1 else sugar)
        else: shutil.copyfile(PRIOR/f'task{task}/B'/file,path)
        if digest(path)!=sha: raise RuntimeError(f'Initial benchmark input mismatch: {task}/{file}')
    manifest['tasks'][str(task)]={'B':dict(old['tasks'][str(task)]['B'])}
(OUT/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
checks={}
cli=OUT/'source/scripts/external-effects/mod_intelligence.py'
for task in (1,2,3):
    work=OUT/f'task{task}/B'
    pins=['--mod','alexsmobs','--expect-version','1.22.17','--expect-sha256','6e502855f79e4c9f2a11d560a9b88a3ab295aa378c44b0f0a0dd95f95d0301a6'] if task==1 else [
        '--mod','alexscaves','--expect-version','2.0.10','--expect-sha256','6fad35bf07fcb977aaa32d3fe05bf122150c6a30ed16b057385040207a3b788f',
        '--expect-dependency-version','2.7.6','--expect-dependency-sha256','9e12468c49e5a95b7adbf22b3b4d05bc55565989b89c40b985cd73bdfe63c3c2']
    p=subprocess.run([sys.executable,'-B',str(cli),'plan','--adaptive','--request',str(work/'request.json'),*pins],
                     capture_output=True,text=True)
    d=json.loads(p.stdout)
    if p.returncode or d.get('schema')!='tno.mod_intelligence.v4' or d.get('status')!='OK':
        raise RuntimeError(d)
    checks[str(task)]={'schema':d['schema'],'status':d['status']}
(OUT/'preflight.json').write_text(json.dumps(checks,indent=2)+'\n')
print(json.dumps({'tasks':3,'all_initial_inputs_match_prior_sha256':True,
    'unchanged_meter':digest(OUT/'meter.py')==digest(PRIOR/'meter.py'),'preflight':checks}))
