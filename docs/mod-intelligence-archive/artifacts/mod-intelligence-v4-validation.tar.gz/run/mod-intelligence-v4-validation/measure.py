import hashlib,json,subprocess,sys
from pathlib import Path
ROOT=Path.cwd();RUN=ROOT/'run/mod-intelligence-v4-validation'
CLI=ROOT/'scripts/external-effects/mod_intelligence.py'
def call(arguments,file):
 result=subprocess.run([sys.executable,'-B',str(CLI),*arguments],capture_output=True,check=True)
 (RUN/file).write_bytes(result.stdout)
 return json.loads(result.stdout),len(result.stdout)
def rows(plan,kind):
 return [i for i in plan['information']['REQUIRED'] if i.get('kind')==kind]
def original_rows(plan,kind):
 return [i for section in ('mechanics','source_locations','preserved_constraints','dependencies','required_tests','patterns','risks_and_questions') for i in plan[section] if i['kind']==kind]
def without_relevance(value):
 return {k:v for k,v in value.items() if k!='relevance'}
examples=[]
for name in ('cockroach_heal','sugar_rush_movement','sugar_rush_dependency','sugar_rush_ambiguous'):
 file=Path('scripts/external-effects/examples/change_requests')/(name+'.json')
 request=json.loads(file.read_text());mod=request['target'].split(':')[0]
 version='1.22.17' if mod=='alexsmobs' else '2.0.10'
 digest='6e502855f79e4c9f2a11d560a9b88a3ab295aa378c44b0f0a0dd95f95d0301a6' if mod=='alexsmobs' else '6fad35bf07fcb977aaa32d3fe05bf122150c6a30ed16b057385040207a3b788f'
 args=['plan','--request',str(file),'--mod',mod,'--expect-version',version,'--expect-sha256',digest]
 if mod=='alexscaves':args+=['--expect-dependency-version','2.7.6','--expect-dependency-sha256','9e12468c49e5a95b7adbf22b3b4d05bc55565989b89c40b985cd73bdfe63c3c2']
 v3,n3=call(args,name+'-v3.json');v4,n4=call([*args,'--adaptive'],name+'-v4.json')
 p3,p4=v3['data'],v4['data'];checks=[]
 checks.append(('catalog_inputs',v3['inputs']==v4['inputs']))
 checks.append(('native_source_check',p3['source_check']==p4['source_check']))
 checks.append(('request_file_pin',p3['intent_input']==p4['intent_input']))
 checks.append(('repository_pins',p3['repository_inputs']==p4['repository_inputs']))
 if name!='sugar_rush_ambiguous':
  checks.append(('literal_site_and_binding',without_relevance(rows(p4,'CURRENT_LITERAL_SITE')[0])==original_rows(p3,'CURRENT_LITERAL_SITE')[0]))
  indices={'cockroach_heal':{0},'sugar_rush_movement':{1,2},'sugar_rush_dependency':{4}}[name]
  for i in indices:
   a=next(r['record'] for r in rows(p4,'RECORDED_COMPONENT') if r['component_index']==i)
   b=next(r['record'] for r in original_rows(p3,'RECORDED_COMPONENT') if r['component_index']==i)
   checks.append(('component_'+str(i),a==b))
  a=rows(p4,'RECORDED_CONTRACT')[0]['record']['contract'];b=original_rows(p3,'RECORDED_CONTRACT')[0]['record']['contract']
  for key in ['source_actor']+(['hurt_return_dependency','lifecycle'] if name.startswith('sugar') else []):
   checks.append(('contract_'+key,a[key]==b[key]))
  if name=='sugar_rush_movement':
   for gate in ('tick','slow_fall'):checks.append(('gate_'+gate,a['binary_parameters'][gate]==b['binary_parameters'][gate]))
   dep4=rows(p4,'RECORDED_OBLIGATION')[0]['record'];dep3=p3['dependencies'][0]['record']
   for key in ('artifact','status','validation_state','source_check','missing_method_hashes'):
    checks.append(('dependency_'+key,dep4[key]==dep3[key]))
  if name=='sugar_rush_dependency':
   checks.append(('all_binary_gates',a['binary_parameters']==b['binary_parameters']))
   checks.append(('full_dependency_record',rows(p4,'RECORDED_OBLIGATION')[0]['record']==p3['dependencies'][0]['record']))
   checks.append(('coupled_native_uses',without_relevance(rows(p4,'COUPLED_NATIVE_USES')[0])==original_rows(p3,'COUPLED_NATIVE_USES')[0]))
   checks.append(('all_dependency_evidence',len(p4['evidence'])==len(p3['evidence'])))
 else:
  candidates4=next(i['candidates'] for i in p4['information']['UNKNOWN'] if i.get('kind')=='PARAMETER_SELECTION')
  candidates3=next(i['candidates'] for i in p3['risks_and_questions'] if i['kind']=='PARAMETER_SELECTION')
  checks.extend([('no_exclusion',not p4['information']['EXCLUDE']),('no_edit',not rows(p4,'PROPOSED_EDIT')),('candidates',candidates3==candidates4),('scope_unknown',p4['scope']['sufficiency']=='NOT_ESTABLISHED')])
 loss=sum(not value for _,value in checks)
 if loss:raise ValueError((name,[key for key,value in checks if not value]))
 counts=p4['selection_counts']
 metric=dict(example=name,target=request['target'],v3_bytes=n3,v4_bytes=n4,reduction_bytes=n3-n4,
  reduction_percent=round(100*(n3-n4)/n3,2),profile=p4['scope']['profile_id'],relevance_counts=counts,
  required_probes=len(checks),lost_required_information=loss,false_exclusions=0,
  loss_measure='Independent required-field oracle and reject-before-output exclusion tests; not a global semantic guarantee.',
  backend_catalog_files=len(v4['inputs']),backend_catalog_reads_reduced=False,
  context_body_omitted=True,exclusion_runtime_impact='NOT_PROVEN')
 examples.append(metric);print(json.dumps(metric,separators=(',',':')))
source_files=['scripts/external-effects/mod_intelligence.py','scripts/external-effects/mod_intelligence_adaptive.py','scripts/external-effects/mod_intelligence_scope_profiles.json']
summary=dict(schema='tno.mod_intelligence.v4_measurements.v1',baseline_commit='804c6a30d1b9b0eb054b2e8ee13c626553b7796c',
 examples=examples,implementation_sha256={f:hashlib.sha256(Path(f).read_bytes()).hexdigest() for f in source_files},
 complexity=dict(adaptive_engine_lines=len(Path(source_files[1]).read_text().splitlines()),scope_profiles=3,new_package_dependencies=0,new_model_calls=0),
 usage_savings='NOT_MEASURED',minimum_claim='Sufficient only under pinned literal-edit profiles; not a proof of global minimum or runtime independence.')
(RUN/'measurements.json').write_text(json.dumps(summary,indent=2)+'\n')
