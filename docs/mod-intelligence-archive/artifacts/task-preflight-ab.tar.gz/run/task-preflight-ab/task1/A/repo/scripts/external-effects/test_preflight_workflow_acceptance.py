import copy
import math
import unittest
from examples.sugar_rush_workflow import load_contract, WorkflowError, float32

class CodingTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls): cls.c,_=load_contract()

    def frames(self):
        return [dict(velocity=(1,2,3),on_server=True,remaining_duration=10,slow_falling_present=False),
                dict(velocity=(4,-2,6),on_server=True,remaining_duration=10,slow_falling_present=False),
                dict(velocity=(7,-3,9),on_server=False,remaining_duration=10,slow_falling_present=False)]

    def test_ordered_trace_changes_upward_server_y_only(self):
        r=self.c.preview_frames(self.frames())
        self.assertEqual([x['velocity'] for x in r],[(1,1.9,3),(4,-0.9,6),(7,-3,9)])
        self.assertEqual([x['effect_tick_return'] for x in r],[True,True,True])

    def test_client_sound_is_observable_and_does_not_move(self):
        r=self.c.preview_frames([self.frames()[2]])[0]
        self.assertEqual(r['actions'],['NATIVE_SOUND']); self.assertIsNone(r['slow_falling_request'])

    def test_slow_falling_has_original_duration_amplifier_and_flags(self):
        r=self.c.preview_frames([self.frames()[1]])[0]
        self.assertEqual(r['actions'],['SET_MOVEMENT','REQUEST_SLOW_FALLING'])
        self.assertEqual(r['slow_falling_request'],dict(duration=10,amplifier=0,flags=[False]*3))

    def test_present_slow_falling_suppresses_request_only(self):
        f=dict(self.frames()[1],slow_falling_present=True)
        r=self.c.preview_frames([f])[0]
        self.assertEqual(r['velocity'],(4,-0.9,6)); self.assertIsNone(r['slow_falling_request'])
        self.assertEqual(r['actions'],['SET_MOVEMENT'])

    def test_nonpositive_duration_suppresses_all_actions_and_returns_false(self):
        for server in (True,False):
            for duration in (0,-1):
                with self.subTest(server=server,duration=duration):
                    f=dict(self.frames()[1],on_server=server,remaining_duration=duration)
                    r=self.c.preview_frames([f])[0]
                    self.assertEqual(r['velocity'],f['velocity']); self.assertEqual(r['actions'],[])
                    self.assertFalse(r['effect_tick_return']); self.assertIsNone(r['slow_falling_request'])

    def test_zero_y_and_custom_upward_factor(self):
        zero=dict(self.frames()[0],velocity=(1,0,3))
        r=self.c.preview_frames([zero,self.frames()[0]],upward_factor=0.5)
        self.assertEqual(r[0]['velocity'],(1,0.0,3)); self.assertIsNone(r[0]['slow_falling_request'])
        self.assertEqual(r[1]['velocity'],(1,1.0,3))

    def test_amplifier_owner_and_add_effect_result_do_not_gate_motion(self):
        a=dict(self.frames()[1],amplifier=0,owner=None,add_effect_accepted=False)
        b=dict(a,amplifier=7,owner='other',add_effect_accepted=True)
        self.assertEqual(self.c.preview_frames([a])[0],self.c.preview_frames([b])[0])

    def test_empty_trace_and_original_motion_unchanged(self):
        self.assertEqual(self.c.preview_frames([]),[])
        self.assertEqual(self.c.motion((1,2,3))['velocity'],(1,1.7,3))
        self.assertEqual(self.c.controller_query(0)['client_tick_ms'],200)
        self.assertEqual(self.c.attribute_amount(1),0.5)

    def test_trace_inputs_template_and_outputs_are_isolated(self):
        frames=[self.frames()[1],self.frames()[1]]; saved=copy.deepcopy(frames)
        template=copy.deepcopy(self.c.slow_fall); r=self.c.preview_frames(frames)
        self.assertEqual(frames,saved)
        r[0]['slow_falling_request']['flags'][0]=True
        self.assertEqual(r[1]['slow_falling_request']['flags'],[False]*3)
        self.assertEqual(self.c.slow_fall,template)
        self.assertEqual(self.c.preview_frames(frames)[0]['slow_falling_request'],template)

    def test_bad_policy_and_malformed_frame_fail_explicitly(self):
        for factor in (True,0,-1,float('nan'),float('inf'),'0.95'):
            with self.subTest(factor=factor),self.assertRaises(WorkflowError):
                self.c.preview_frames(self.frames(),upward_factor=factor)
        for frame in (None,dict(self.frames()[0],velocity=(1,2)),dict(self.frames()[0],velocity=(1,float('nan'),3))):
            with self.subTest(frame=frame),self.assertRaises(WorkflowError): self.c.preview_frames([frame])


class RepositoryCliTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls): cls.c,_=load_contract()

    def invoke(self, raw, *args):
        import json, subprocess, sys, tempfile
        from pathlib import Path
        from examples.sugar_rush_workflow import CLI
        with tempfile.TemporaryDirectory() as directory:
            path=Path(directory)/'frames.json'; path.write_text(raw)
            p=subprocess.run([sys.executable,'-B',str(CLI.parent/'examples/sugar_rush_workflow.py'),
                '--frames-file',str(path),*args],capture_output=True,text=True)
        return p,json.loads(p.stdout)

    def test_cli_frame_mode_preserves_provenance_and_returns_trace(self):
        import json
        frames=CodingTests().frames()
        p,r=self.invoke(json.dumps(frames))
        self.assertEqual(p.returncode,0,p.stderr)
        self.assertEqual(r['status'],'OK')
        self.assertEqual(r['fixture'],'alexscaves:sugar_rush')
        self.assertEqual(r['scope'],'STATIC_CODING_FIXTURE_ONE_LOCAL_MODIFIER')
        self.assertTrue(r['provenance']); self.assertTrue(r['cli_output_bytes'])
        self.assertEqual(r['frames'][0]['velocity'],[1,1.9,3])
        self.assertEqual(r['frames'][2]['actions'],['NATIVE_SOUND'])

    def test_cli_custom_policy_and_empty_frames(self):
        import json
        p,r=self.invoke(json.dumps(CodingTests().frames()),'--upward-factor','0.5')
        self.assertEqual(p.returncode,0); self.assertEqual(r['frames'][0]['velocity'],[1,1.0,3])
        p,r=self.invoke('[]');self.assertEqual(p.returncode,0);self.assertEqual(r['frames'],[])

    def test_cli_invalid_json_and_structure_fail_with_json_error(self):
        for raw in ('{','[null]','[{"velocity":[1,2,3]}]'):
            with self.subTest(raw=raw):
                p,r=self.invoke(raw);self.assertNotEqual(p.returncode,0);self.assertEqual(r['status'],'ERROR')
                self.assertNotIn('Traceback',p.stderr)

    def test_numeric_and_flag_validation(self):
        frame=CodingTests().frames()[0]
        for patch in ({'velocity':(True,2,3)},{'on_server':1},{'slow_falling_present':0},
                      {'remaining_duration':float('inf')}):
            with self.subTest(patch=patch),self.assertRaises(WorkflowError):
                self.c.preview_frames([dict(frame,**patch)])

    def test_finite_input_overflow_is_a_workflow_error(self):
        import json
        frame=CodingTests().frames()[0]
        with self.assertRaises(WorkflowError):self.c.preview_frames([frame],upward_factor=1e308)
        p,r=self.invoke(json.dumps([frame]),'--upward-factor','1e308')
        self.assertNotEqual(p.returncode,0);self.assertEqual(r['status'],'ERROR')
        self.assertNotIn('Traceback',p.stderr)
