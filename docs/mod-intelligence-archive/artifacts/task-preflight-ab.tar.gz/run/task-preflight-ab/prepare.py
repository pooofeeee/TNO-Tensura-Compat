"""Freeze an actual repository-tool change identically for both coding arms."""
from pathlib import Path
import hashlib,json,shutil,subprocess,sys,time
ROOT=Path('/workspace/mod-intelligence-v1'); OUT=Path(__file__).resolve().parent
PRIOR=ROOT/'run/mod-intelligence-astra-medium-evaluation'
TARGET='scripts/external-effects/examples/sugar_rush_workflow.py'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
spec=(PRIOR/'task3/B/spec.txt').read_text()+'''
Apply this change to the existing repository module
scripts/external-effects/examples/sugar_rush_workflow.py, retaining its architecture.
Expose it through that module's existing CLI with --frames-file PATH (a JSON
array) and --upward-factor FLOAT (default 0.95). In frame mode retain the existing
status, fixture, scope, cli_output_bytes and provenance fields and add frames
containing the preview results. The no-argument demonstration and existing CLI
error protocol must remain unchanged. Invalid JSON, malformed input and nonfinite
computed movement must produce status ERROR and a nonzero exit; API validation
uses WorkflowError. Reject bool/nonfinite policy or velocity components, missing
frame fields, nonboolean side/effect flags, and nonfinite duration. Finite inputs
whose multiplication overflows must fail through WorkflowError. Required tests
include all existing workflow tests and the frozen new acceptance tests. Only
this module may change. These are static repository-tool results, not Minecraft
runtime validation; production and source evidence must remain untouched.
'''
protocol='''Controlled repository coding experiment. Only the assigned existing module
repo/scripts/external-effects/examples/sugar_rush_workflow.py may change.
Use only the provided meter for reads, searches, retrieval, edits, tests and finish.
No direct shell, apply_patch, git, network, other tools, subagents, source rescans,
cross-arm access or inspection of previous benchmark implementations.
One functions.exec with one tools.exec_command per meter operation.
Use max_output_tokens 16000 for evidence retrieval responses.
Operations: read [LINES=start:end] FILE...; search PATTERN PATH...;
cli -- MOD_INTELLIGENCE_ARGS; preflight (B only, frozen manifest); edit; test; finish.
edit reads JSON [{old: exact unique text, new: replacement}] on stdin, or
[{append:true,new:text}]. It can edit only the approved module.
test runs all frozen test_*workflow*.py tests in repo/scripts/external-effects.
finish reads a JSON report with summary, source_evidence, preserved_constraints,
unknowns, restoration_needed, corrections, non_meter_tool_calls.
Implement the entire spec, run required tests, repair task failures as necessary.
Do not optimize the tools, wrapper, tests, manifest or benchmark during the run.
Preserve exact source pins and UNKNOWNs; native offsets are evidence, not edit
paths. Fixture assertions do not establish Minecraft runtime correctness.
A uses existing V4 first; its documented V3/V1 restoration is allowed when needed.
B uses Task Preflight first; existing retrieval remains available if necessary.
Keep assigned GPT-6 Astra Medium settings. No publication or commits.
'''
acceptance=(PRIOR/'task3/B/test_acceptance.py').read_text().replace('from solution import','from examples.sugar_rush_workflow import')
acceptance+='''

class RepositoryCliTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls): cls.c,_=load_contract()

    def invoke(self, raw, *args):
        import json, subprocess, sys, tempfile
        from pathlib import Path
        from examples.sugar_rush_workflow import CLI
        with tempfile.TemporaryDirectory() as directory:
            path=Path(directory)/'frames.json'; path.write_text(raw)
            p=subprocess.run([sys.executable,'-B',str(CLI.parent/'examples/sugar_rush_workflow.py'),
                '--frames-file',str(path),*args],capture_output=True,text=True)
        return p,json.loads(p.stdout)

    def test_cli_frame_mode_preserves_provenance_and_returns_trace(self):
        import json
        frames=CodingTests().frames()
        p,r=self.invoke(json.dumps(frames))
        self.assertEqual(p.returncode,0,p.stderr)
        self.assertEqual(r['status'],'OK')
        self.assertEqual(r['fixture'],'alexscaves:sugar_rush')
        self.assertEqual(r['scope'],'STATIC_CODING_FIXTURE_ONE_LOCAL_MODIFIER')
        self.assertTrue(r['provenance']); self.assertTrue(r['cli_output_bytes'])
        self.assertEqual(r['frames'][0]['velocity'],[1,1.9,3])
        self.assertEqual(r['frames'][2]['actions'],['NATIVE_SOUND'])

    def test_cli_custom_policy_and_empty_frames(self):
        import json
        p,r=self.invoke(json.dumps(CodingTests().frames()),'--upward-factor','0.5')
        self.assertEqual(p.returncode,0); self.assertEqual(r['frames'][0]['velocity'],[1,1.0,3])
        p,r=self.invoke('[]');self.assertEqual(p.returncode,0);self.assertEqual(r['frames'],[])

    def test_cli_invalid_json_and_structure_fail_with_json_error(self):
        for raw in ('{','[null]','[{"velocity":[1,2,3]}]'):
            with self.subTest(raw=raw):
                p,r=self.invoke(raw);self.assertNotEqual(p.returncode,0);self.assertEqual(r['status'],'ERROR')
                self.assertNotIn('Traceback',p.stderr)

    def test_numeric_and_flag_validation(self):
        frame=CodingTests().frames()[0]
        for patch in ({'velocity':(True,2,3)},{'on_server':1},{'slow_falling_present':0},
                      {'remaining_duration':float('inf')}):
            with self.subTest(patch=patch),self.assertRaises(WorkflowError):
                self.c.preview_frames([dict(frame,**patch)])

    def test_finite_input_overflow_is_a_workflow_error(self):
        import json
        frame=CodingTests().frames()[0]
        with self.assertRaises(WorkflowError):self.c.preview_frames([frame],upward_factor=1e308)
        p,r=self.invoke(json.dumps([frame]),'--upward-factor','1e308')
        self.assertNotEqual(p.returncode,0);self.assertEqual(r['status'],'ERROR')
        self.assertNotIn('Traceback',p.stderr)
'''
manifest={'commit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip(),
 'model':'gpt-6-astra','effort':'medium','task':'Existing repository Sugar Rush offline preview API and CLI',
 'production_runtime_task':False,'target':TARGET,'frozen':{},'treatment':'Wrapper only; existing V4 and tests identical',
 'usage_telemetry':None,'manifest_preparation':{}}
for arm in ('A','B'):
 work=OUT/'task1'/arm; work.mkdir(parents=True);repo=work/'repo'
 shutil.copytree(PRIOR/'source',repo,symlinks=True)
 shutil.copyfile(ROOT/'scripts/external-effects/task_preflight.py',repo/'scripts/external-effects/task_preflight.py')
 (work/'spec.txt').write_text(spec);(work/'protocol.txt').write_text(protocol)
 (repo/'task_request.json').write_bytes((PRIOR/'task3/B/request.json').read_bytes())
 (repo/'scripts/external-effects/test_preflight_workflow_acceptance.py').write_text(acceptance)
 start=time.perf_counter()
 def pin(file):return {'file':file,'sha256':sha(repo/file)}
 tests=['scripts/external-effects/test_mod_intelligence_workflow.py',
        'scripts/external-effects/test_mod_intelligence_animation_workflow.py',
        'scripts/external-effects/test_preflight_workflow_acceptance.py']
 task={'schema':'tno.task_manifest.v1','task_type':'preservation_behavior',
 'scope':{'kind':'broader_implementation','description':spec},'change_request':pin('task_request.json'),
 'approved_edit_targets':[pin(TARGET)],
 'required_tests':[dict(pin(f),command=['python3','-B','-m','unittest','discover','-s','scripts/external-effects','-p',Path(f).name,'-q']) for f in tests],
 'sources':{'native':{'mod':'alexscaves','version':'2.0.10','sha256':'6fad35bf07fcb977aaa32d3fe05bf122150c6a30ed16b057385040207a3b788f'},'dependency':{'mod':'citadel','version':'2.7.6','sha256':'9e12468c49e5a95b7adbf22b3b4d05bc55565989b89c40b985cd73bdfe63c3c2'}},'unresolved_questions':[]}
 (work/'task.json').write_text(json.dumps(task,indent=2)+'\n')
 manifest['manifest_preparation'][arm]={'mechanical_generation_seconds':time.perf_counter()-start,'bytes':(work/'task.json').stat().st_size,'authoring_cost':'Not captured; evaluator created manifest from shared spec and known pins before both runs','agent_generation_operations':0}
 manifest['frozen'][arm]={str(p.relative_to(work)):sha(p) for p in work.rglob('*') if p.is_file() and not p.is_symlink()}
# Require identical input bytes. No resolved absolute arm paths are embedded.
if manifest['frozen']['A']!=manifest['frozen']['B']:raise RuntimeError('Arm inputs differ')
manifest['meter_sha256']=sha(OUT/'meter.py')
(OUT/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps({'identical_files_per_arm':len(manifest['frozen']['A']),'task_spec_bytes':len(spec.encode()),'new_acceptance_tests':15,'wrapper_sha256':sha(ROOT/'scripts/external-effects/task_preflight.py')}))
