"""Read-only replay of Astra's original five V1 corruptions."""
import contextlib
import io
import json
import sys
from unittest.mock import patch

sys.path.insert(0, sys.argv[1] + '/scripts/external-effects')
import mod_intelligence as mi

ID = 'alexscaves:sugar_rush'
FILE = 'native-evidence/alexscaves-status-foundation.json'

def row(catalog):
    return next(r for r in catalog.review('alexscaves')['effects'] if r['id'] == ID)

def witness(catalog):
    return next(w for w in catalog.index.read(FILE)['witnesses']
                if w['entry'].endswith('/SugarRushEffect.class'))

def invoke(catalog, arguments):
    out = io.StringIO()
    try:
        with patch.object(mi, 'Catalog', return_value=catalog), contextlib.redirect_stdout(out):
            code = mi.main(arguments)
        result = json.loads(out.getvalue())
        return {'exit': code, 'status': result['status'], 'error': result.get('error')}
    except Exception as error:
        return {'uncaught': type(error).__name__, 'message': str(error), 'stdout': out.getvalue()}

def replay():
    results = {}
    catalog = mi.Catalog()
    component = next(c for c in row(catalog)['components'] if c['primitive'] == 'FORCED_MOVEMENT')
    component['numerical_parameters']['downward_y_factor'] = 0.6
    results['1_nested_binding'] = invoke(catalog, ['get', ID, '--mod', 'alexscaves', '--section', 'numbers'])

    for value, name in ((None, 'missing'), ('', 'empty')):
        catalog = mi.Catalog()
        w = witness(catalog)
        if value is None:
            del w['jar_sha256']
        else:
            w['jar_sha256'] = value
        results['2_native_pin_' + name] = invoke(catalog, ['get', ID, '--mod', 'alexscaves', '--section', 'evidence'])

    catalog = mi.Catalog()
    method = next(m for m in witness(catalog)['methods'] if m['name'] == 'applyEffectTick')
    method['code_hex'] = '00'
    results['3_code_hash'] = invoke(catalog, ['get', ID, '--mod', 'alexscaves'])

    catalog = mi.Catalog()
    catalog.inventory['targets'][0]['metadata'] = [None]
    results['4a_metadata_null'] = invoke(catalog, ['mods'])
    catalog = mi.Catalog()
    row(catalog)['components'][0]['numerical_parameters']['movement_speed_coefficient'] = float('nan')
    results['4b_nan'] = invoke(catalog, ['get', ID, '--mod', 'alexscaves'])

    catalog = mi.Catalog()
    r = row(catalog)
    proof = dict(r['implementation'][0])
    file = proof.pop('evidence_file')
    proof['witness_id'] = 'WRONG'
    r['implementation'][0] = proof
    r['reference_evidence'] = [file]
    results['5_unqualified_witness_id'] = invoke(catalog, ['get', ID, '--mod', 'alexscaves'])
    return results

results = replay()
label = sys.argv[2]
for name, result in results.items():
    if label == 'baseline':
        if name in ('4a_metadata_null', '4b_nan'):
            expected = result.get('uncaught') in ('AttributeError', 'ValueError') and result.get('stdout') == ''
        else:
            expected_exit = 2 if name == '3_code_hash' and not sys.flags.optimize else 0
            expected = result.get('exit') == expected_exit
    else:
        expected = result.get('exit') == 2 and result.get('status') == 'ERROR' and 'uncaught' not in result
    if not expected:
        raise RuntimeError(f'Unexpected reproduction outcome {label}/{name}: {result}')
print(json.dumps({'revision': label, 'optimization': sys.flags.optimize, 'cases': results}, sort_keys=True))
