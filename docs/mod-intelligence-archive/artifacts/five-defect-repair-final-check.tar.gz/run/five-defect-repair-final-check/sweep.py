import hashlib, json, sys
sys.path.insert(0, sys.argv[1] + '/scripts/external-effects')
from mod_intelligence import Catalog
catalog = Catalog()
results = {}
for key in catalog.completed_keys():
    for row in catalog.review(key)['effects']:
        result = catalog.get(row['id'], key)
        raw = json.dumps(result, sort_keys=True, separators=(',', ':'), allow_nan=False).encode()
        results[row['id']] = hashlib.sha256(raw).hexdigest()
with open(sys.argv[2], 'w') as output:
    json.dump(results, output, sort_keys=True)
print(json.dumps({'mechanics': len(results), 'completed_mods': len(catalog.completed_keys())}))
