"""Frozen behavioral oracle for both A/B arms; does not execute any CLI."""
import unittest

from sugar_rush_workflow import SugarRush


class MotionIsolationTests(unittest.TestCase):
    def setUp(self):
        # Only the three motion inputs are relevant; other fields are inert.
        self.contract = SugarRush(coefficient=0, upward=0.85, downward=0.45,
            slow_fall=dict(duration=10, amplifier=0, flags=[False, False, False]),
            speed_multiplier=0, flying_factor=0, duration_multiplier=0,
            radius=0, local_multiplier=0, normal_ms=0, regular_duration=0,
            long_duration=0, provenance={})

    def test_mutating_return_does_not_change_contract_or_next_preview(self):
        request = self.contract.motion((1, -2, 3))['slow_falling_request']
        request['duration'] = 999
        request['flags'][0] = True
        expected = dict(duration=10, amplifier=0, flags=[False] * 3)
        self.assertEqual(self.contract.slow_fall, expected)
        self.assertEqual(self.contract.motion((1, -2, 3))['slow_falling_request'], expected)

    def test_mutating_one_preview_does_not_change_an_existing_preview(self):
        first = self.contract.motion((1, -2, 3))['slow_falling_request']
        second = self.contract.motion((1, -2, 3))['slow_falling_request']
        first['amplifier'] = 3
        first['flags'].append(True)
        self.assertEqual(second, dict(duration=10, amplifier=0, flags=[False] * 3))

    def test_verified_directional_motion_and_effect_payload_are_preserved(self):
        self.assertEqual(self.contract.motion((1, -2, 3)), dict(
            velocity=(1, -0.9, 3), slow_falling_request=dict(
                duration=10, amplifier=0, flags=[False] * 3)))
        self.assertEqual(self.contract.motion((1, 2, 3)), dict(
            velocity=(1, 1.7, 3), slow_falling_request=None))
        self.assertEqual(self.contract.motion((1, 0, 3)), dict(
            velocity=(1, 0, 3), slow_falling_request=None))

    def test_existing_server_duration_and_effect_presence_gates_are_preserved(self):
        for options, expected in [
            (dict(on_server=False), (1, -2, 3)),
            (dict(remaining_duration=0), (1, -2, 3)),
            (dict(remaining_duration=-1), (1, -2, 3)),
            (dict(slow_falling_present=True), (1, -0.9, 3)),
        ]:
            with self.subTest(options=options):
                result = self.contract.motion((1, -2, 3), **options)
                self.assertEqual(result['velocity'], expected)
                self.assertIsNone(result['slow_falling_request'])


if __name__ == '__main__':
    unittest.main()
