"""Meter only evaluation shell operations; isolate each arm's file access."""
import argparse
import datetime
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time

BASE = Path(__file__).resolve().parent
SOURCE = BASE/'source'
p=argparse.ArgumentParser()
p.add_argument('--work',type=Path,required=True)
p.add_argument('operation',choices=['read','search','cli','edit','test','finish'])
p.add_argument('args',nargs=argparse.REMAINDER)
a=p.parse_args(); work=a.work.resolve()
if work.parent.parent != BASE or work.name not in ('A','B'):
    raise ValueError('Not an evaluation arm')
log=work/'events.jsonl'
events=[json.loads(s) for s in log.read_text().splitlines()] if log.exists() else []
index=len(events)+1
started=time.monotonic()
event=dict(index=index,operation=a.operation,arguments=a.args,
    utc=datetime.datetime.now(datetime.timezone.utc).isoformat())

def allowed(path):
    # Allow frozen source catalog through its explicitly pinned symlink only.
    raw=Path(path); raw=raw if raw.is_absolute() else work/raw
    lexical=Path(os.path.abspath(raw))
    if not (lexical.is_relative_to(work) or lexical.is_relative_to(SOURCE)):
        raise ValueError('Access outside own arm or frozen source')
    resolved=lexical.resolve()
    if lexical.is_relative_to(SOURCE/'docs/benchmarks/external-effects-catalog'):
        if not resolved.is_relative_to((SOURCE/'docs/benchmarks/external-effects-catalog').resolve()):
            raise ValueError('Catalog path escape')
    elif not (resolved.is_relative_to(work) or resolved.is_relative_to(SOURCE)):
        raise ValueError('Path escape')
    return lexical

def child(cmd):
    event['command']=cmd
    result=subprocess.run(cmd,cwd=work,capture_output=True,text=True,
        env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1',PYTHONOPTIMIZE='0'))
    event['exit']=result.returncode
    event['stderr']=result.stderr
    return result.stdout+result.stderr

output=''; exit_code=0
try:
    if a.operation=='read':
        files=[]; ranges={}; args=list(a.args)
        # optional first argument LINES=start:end, applied to each file
        start,end=1,None
        if args and args[0].startswith('LINES='):
            limits=args.pop(0)[6:].split(':'); start=int(limits[0]); end=int(limits[1]) if limits[1] else None
        for name in args:
            path=allowed(name); raw=path.read_text()
            selected='\n'.join(raw.splitlines()[start-1:end])+'\n'
            output+=f'FILE {path} LINES {start}:{end or "end"}\n'+selected
            files.append(str(path)); ranges[str(path)]=[start,end]
        event['files_inspected']=files; event['ranges']=ranges
    elif a.operation=='search':
        pattern,*paths=a.args
        if not paths: paths=['.']
        paths=[str(allowed(x)) for x in paths]
        output=child(['rg','-n','--max-count','20','--',pattern,*paths])
        event['searched_paths']=paths
    elif a.operation=='cli':
        args=a.args[1:] if a.args and a.args[0]=='--' else a.args
        output=child([sys.executable,'-B',str(SOURCE/'scripts/external-effects/mod_intelligence.py'),*args])
        file=work/f'cli-{index:03d}.json'; file.write_text(output)
        event['response_file']=str(file)
        try:
            data=json.loads(output)
            event['schema']=data.get('schema'); event['catalog_inputs']=data.get('inputs',[])
            if data.get('data',{}).get('scope'):
                event['scope']=data['data']['scope']
        except ValueError: pass
        exit_code=event['exit']
    elif a.operation=='edit':
        changes=json.load(sys.stdin); path=work/'solution.py'; text=path.read_text()
        event['before_sha256']=hashlib.sha256(text.encode()).hexdigest()
        event['changes']=changes
        for change in changes:
            if change.get('append'):
                text+=change['new']
            else:
                old=change['old']
                if not old or text.count(old)!=1:
                    raise ValueError('Replacement requires exactly one original match')
                text=text.replace(old,change['new'],1)
        path.write_text(text)
        event['after_sha256']=hashlib.sha256(text.encode()).hexdigest()
        output=json.dumps(dict(edited='solution.py',replacements=len(changes)))+'\n'
    elif a.operation=='test':
        flags=['-O'] if '-O' in a.args else []
        output=child([sys.executable,'-B',*flags,'-m','unittest','discover','-s',str(work),'-p','test*.py','-q'])
        exit_code=event['exit']
    elif a.operation=='finish':
        report=json.load(sys.stdin)
        (work/'agent_report.json').write_text(json.dumps(report,indent=2)+'\n')
        output=json.dumps(dict(report_saved=True))+'\n'
except Exception as error:
    event['error']=f'{type(error).__name__}: {error}'; exit_code=2
    output=json.dumps(dict(error=event['error']))+'\n'
event['exit']=event.get('exit',exit_code)
event['elapsed_seconds']=round(time.monotonic()-started,6)
event['output_characters']=len(output)
event['output_bytes']=len(output.encode())
event['output_sha256']=hashlib.sha256(output.encode()).hexdigest()
# Keep complete audit output locally; bound large existing-evidence search windows.
(work/f'output-{index:03d}.txt').write_text(output)
if a.operation=='search' and len(output)>16000:
    output=output[:16000]+'\n[Search output limited to 16000 characters; narrow the search.]\n'
    event['output_limited']=True
event['displayed_characters']=len(output)
with log.open('a') as f: f.write(json.dumps(event)+'\n')
print(output,end='')
sys.exit(exit_code)
