"""Assert native event reachability and scalar facts independently of prose."""
import unittest
from catalog_common import OUT,read_json
from collect_combat_census import decode_sites
from promote_combat_batch import validate_batch


class GlobalHooksTests(unittest.TestCase):
    def test_final_player_batch_validates_exact_native_consumers(self):
        batch=read_json(OUT/'arphex-r2m2t-player-reach-aim-and-floating.json')
        review=read_json(OUT/'mod-reviews/arphex.json');ids={r['id'] for r in batch['effects']}
        review['effects']=[r for r in review['effects'] if r['id'] not in ids]
        review['paths']=[p for p in review['paths'] if not set(p['effect_ids'])&ids]
        self.assertEqual(validate_batch(batch,review,self.census)['semantic_records'],len(review['effects'])+3)
        self.assertEqual(sum(len(c['parameters']) for r in batch['effects'] for c in r['scalable_parameter_candidates']),22)

    def test_equipment_reach_requests_keep_modern_values_and_legacy_syntax_distinct(self):
        body=self.body('GameModeDetectorProcedure');by={i['offset']:i for i in body}
        modern={26251:('entity',1),27174:('entity',4),28203:('entity',2),28309:('block',2),29232:('block',2),30049:('block',6),30866:('entity',150)}
        for offset,(kind,value) in modern.items():
            at=next(n for n,i in enumerate(body) if i['offset']==offset);tokens=body[at-1]['operand'].split()
            self.assertEqual(tokens[2],f'minecraft:player.{kind}_interaction_range')
            self.assertEqual(tokens[6:],[str(value),'add_value'])
        legacy=next(n for n,i in enumerate(body) if i['offset']==25933)
        self.assertEqual(body[legacy-1]['operand'].split()[6:],['arphexreach','1','add'])
        grammar=read_json(OUT/'vanilla-evidence/arphex-attribute-command.json')['classes'][0]['methods'][0]['instructions']
        words=[i['operand'] for i in grammar if i['opcode'] in ('0x12','0x13')]
        at=words.index('modifier');self.assertEqual(words[at:at+5],['modifier','add','id','value','add_value'])
        self.assertTrue(any('ResourceLocationArgument.id()' in str(i['operand']) for i in grammar))
        self.assertEqual(by[26474]['operand'],'paralysis')
        self.assertIn('.putString(',by[26477]['operand']) # latch outside server command path

    def test_raw_recoil_controls_pitch_not_a_damage_request(self):
        body=self.body('GameModeDetectorProcedure');by={i['offset']:i for i in body}
        self.assertEqual(by[31729]['operand'],7.0)
        self.assertEqual([by[n]['opcode'] for n in (31732,31733,31734)],['0x6f','0x67','0x90'])
        self.assertIn('.setXRot(',by[31735]['operand'])
        self.assertFalse(any('.hurt(' in str(i['operand']) for i in body if 31667<=i['offset']<=31834))

    def test_floating_latch_and_resource_updates_are_not_post_clamped(self):
        body=self.body('GameModeDetectorProcedure');by={i['offset']:i for i in body}
        self.assertEqual(by[31910]['branch_target'],33696)
        self.assertEqual(by[33589]['operand'],'allow_floatingsequence')
        at=next(n for n,i in enumerate(body) if i['offset']==33589)
        self.assertEqual(body[at+1]['operand'],40.0)
        self.assertIn('.putDouble(',body[at+2]['operand'])
        self.assertEqual(by[32554]['operand'],2.0)
        self.assertEqual([by[n]['opcode'] for n in (32557,32558)],['0x63','0xb6'])
        self.assertEqual(by[32969]['operand'],.05)
        self.assertEqual([by[n]['opcode'] for n in (32972,32973)],['0x63','0xb6'])
        self.assertEqual(by[33127]['operand'],.05)
        self.assertEqual([by[n]['opcode'] for n in (33130,33131)],['0x67','0xb6'])
        self.assertEqual([by[n]['opcode'] for n in (32857,32858)],['0x6e','0x8d']) # float divide then widen

    def test_floating_floor_native_grid_has_repeated_corner(self):
        body=self.body('GameModeDetectorProcedure')
        sites=[n for n,i in enumerate(body) if 33300<=i['offset']<=33490 and 'BlockPos.containing(' in str(i['operand'])]
        self.assertEqual(len(sites),9)
        # Last three corner expressions have three explicit dconst_1 values.
        arithmetic=[[i['opcode'] for i in body[n-11:n] if i['opcode'] in ('0x63','0x67')] for n in sites[-3:]]
        self.assertEqual(arithmetic,[['0x63','0x67','0x67'],['0x63','0x67','0x63'],['0x63','0x67','0x67']])
        self.assertNotIn(['0x67','0x67','0x63'],arithmetic) # omitted negative-X/positive-Z corner
        by={i['offset']:i for i in body}
        self.assertEqual([by[n]['operand'] for n in (33243,33277,33506,33540)],[.02,.04,-.02,.02])

    def test_durability_repair_requires_its_exact_typed_native_sink(self):
        import copy
        batch=read_json(OUT/'arphex-r2m2t-player-reach-aim-and-floating.json')
        review=read_json(OUT/'mod-reviews/arphex.json');ids={r['id'] for r in batch['effects']}
        review['effects']=[r for r in review['effects'] if r['id'] not in ids]
        review['paths']=[p for p in review['paths'] if not set(p['effect_ids'])&ids]
        invalid=copy.deepcopy(batch)
        row=next(r for r in invalid['effects'] if r['id']=='arphex:player_raw_float_motion_control')
        c=next(c for c in row['scalable_parameter_candidates'] if c['primitive']=='ITEM_DURABILITY_REPAIR')
        self.assertEqual(c['native_consumer']['operand'],'net/minecraft/world/item/ItemStack.setDamageValue(I)V')
        c['primitive']='UNRELATED_DAMAGE'
        component=next(c for c in row['components'] if c['primitive']=='ITEM_DURABILITY_REPAIR');component['primitive']='UNRELATED_DAMAGE'
        with self.assertRaisesRegex(AssertionError,'not a native scalar consumer'):validate_batch(invalid,review,self.census)

    def test_tormentor_player_batch_reuses_status_and_counts_native_parameters(self):
        batch=read_json(OUT/'arphex-r2m2s-player-tormentor-state-and-placement.json')
        review=read_json(OUT/'mod-reviews/arphex.json');ids={r['id'] for r in batch['effects']}
        review['effects']=[r for r in review['effects'] if r['id'] not in ids]
        review['paths']=[p for p in review['paths'] if not set(p['effect_ids'])&ids]
        self.assertEqual(validate_batch(batch,review,self.census)['semantic_records'],len(review['effects'])+2)
        self.assertEqual(len(batch['effects']),2)
        self.assertEqual(sum(len(c['parameters']) for r in batch['effects'] for c in r['scalable_parameter_candidates']),3)
        target=next(r for r in batch['record_refinements'] if r['id']=='arphex:tormentor_primary_target')
        self.assertEqual(target['candidate_additions'][0]['native_receiver_binding']['origin_local_index'],8)

    def test_projecte_window_is_exact_acquisition_command_requests(self):
        body=self.body('GameModeDetectorProcedure')
        requests=[n for n,i in enumerate(body) if 16226<=i['offset']<=18452 and '.performPrefixedCommand(' in str(i['operand'])]
        self.assertEqual(len(requests),31)
        for n in requests:
            self.assertIn(body[n-1]['opcode'],('0x12','0x13'))
            self.assertTrue(body[n-1]['operand'].startswith('projecte setemc '))
        self.assertFalse(any('.hurt(' in str(i['operand']) for i in body if 16226<=i['offset']<=18452))

    def test_tormentor_chunk_recipes_preserve_malformed_requests(self):
        entry=self.witness('GameModeDetectorProcedure')['entry']
        recipes={b['index']:b['arguments'][0] for b in self.census['registration_bootstraps'] if b['entry']==entry and b['arguments']}
        self.assertEqual(recipes[64],'execute in \x01 run execute positioned \x01 \x01 \x01run forceload remove ~ ~')
        self.assertEqual(recipes[69],'execute in \x01 run execute positioned \x01 \x01 run forceload remove ~ ~')
        self.assertEqual(recipes[76],'execute in \x01 run execute positioned \x01 \x01 \x01 run forceload remove ~ ~')
        self.assertEqual(recipes[71],'tp @e[type=arphex:tormentor,sort=nearest,limit=1] \x01 \x01 \x01')
        body=self.body('GameModeDetectorProcedure');by={i['offset']:i for i in body}
        for offset in (19988,20712,21158,22804,24039,24555):
            self.assertTrue(by[offset]['operand'].endswith('Ljava/lang/String;)V')) # no success result

    def test_tormentor_integer_timer_and_live_follow_formula_are_native(self):
        body=self.body('GameModeDetectorProcedure');by={i['offset']:i for i in body}
        self.assertEqual([by[n]['opcode'] for n in (22497,22498,22499,22500)],['0x6c','0x87','0x67','0xb5'])
        self.assertEqual(1//2,0)
        for offset in (20477,20519,20538,20578,23477,23645,23664,23704):
            self.assertIn('TORMENTOR_FOLLOW_SPEED',by[offset]['operand'])
        self.assertEqual(by[20550]['operand'],2.0)
        self.assertEqual(by[20555]['local_index'],78)
        for n in (21182,24194):self.assertEqual(by[n]['local_index'],78)
        self.assertIn('tormentor_yD',by[21184]['operand'])
        self.assertIn('tormentor_yD',by[24196]['operand'])
        self.assertEqual(by[23230]['operand'],'torteletime')
        self.assertEqual(by[23233]['operand'],60.0)
        self.assertIn('.putDouble(',by[23236]['operand'])
        config=next(w for w in self.native['witnesses'] if w['entry'].endswith('/ConfigurationSettingsConfiguration.class'))['methods'][0]['instructions']
        defaults={i['offset']:i for i in config}
        self.assertEqual(defaults[488]['operand'],25.0)
        self.assertIn('.define(',defaults[494]['operand']) # comment range is not defineInRange

    def test_tormentor_entry_guards_do_not_exit_after_native_disable_writes(self):
        body=self.body('GameModeDetectorProcedure');by={i['offset']:i for i in body}
        self.assertEqual(by[19420]['branch_target'],19868)
        self.assertEqual(by[19472]['operand'],0.0)
        self.assertEqual(by[19473]['opcode'],'0xb5')
        self.assertEqual(by[19536]['opcode'],'0xb5')
        self.assertIn('EntityType.spawn(',by[19835]['operand'])
        self.assertEqual(by[24800]['branch_target'],25032)
        self.assertEqual(by[24822]['operand'],0.0)
        self.assertEqual(by[24823]['opcode'],'0xb5')
        self.assertEqual(by[21521]['opcode'],'0xb5') # clear follow UUID first
        self.assertEqual([by[n]['operand'] for n in (21567,21569,21570,21571)],[60,0,0,0])
        self.assertIn('TORMENTOR_PRIMARY_TARGET',by[21564]['operand'])
        self.assertIn('removeEffect(',by[18513]['operand'])
        self.assertFalse(any('isClientSide' in str(i['operand']) for i in body if 18453<=i['offset']<18513))

    def test_tormentor_reward_item_protection_has_bound_item_actor(self):
        body=self.body('GameModeDetectorProcedure');at=next(n for n,i in enumerate(body) if i['offset']==19405)
        self.assertEqual(body[at-1]['operand'],'data merge entity @s {Glowing:1b,Invulnerable:1b}')
        ctor=next(n for n,i in enumerate(body[:at]) if i['offset']==19399)
        self.assertEqual(body[ctor-1]['local_index'],139) # queried item, not Player local8
        self.assertEqual(body[ctor-1]['opcode'],'0x19')

    @classmethod
    def setUpClass(cls):
        cls.census=read_json(OUT/'arphex-combat-census.json')
        cls.native=read_json(OUT/'native-evidence/arphex-global-hooks.json')
        cls.batch=read_json(OUT/'arphex-r2m2c-small-global-deliveries.json')

    def witness(self,name):
        return next(w for w in self.native['witnesses'] if w['entry']==f'net/arphex/procedures/{name}.class')

    def test_small_batch_native_consumers_and_unique_identities(self):
        review=read_json(OUT/'mod-reviews/arphex.json');ids={r['id'] for r in self.batch['effects']}
        review['effects']=[r for r in review['effects'] if r['id'] not in ids]
        review['paths']=[p for p in review['paths'] if not set(p['effect_ids'])&ids]
        self.assertEqual(validate_batch(self.batch,review,self.census)['semantic_records'],
                         len(review['effects'])+len(self.batch['effects']))
        self.assertEqual(len(ids),9)

    def test_method_annotation_without_class_or_caller_is_not_live_registration(self):
        w=self.witness('EntitySpawnReasonProcedure')
        self.assertFalse(any(a['descriptor'].endswith('/EventBusSubscriber;') for a in w['annotations']))
        self.assertTrue(any(a['descriptor'].endswith('/SubscribeEvent;') for m in w['methods'] for a in m['annotations']))
        target='net/arphex/procedures/EntitySpawnReasonProcedure.'
        external=[(m,s) for m in self.census['methods'] if not m['entry'].startswith(w['entry'][:-6])
                  for s in decode_sites(self.census,m,'calls') if target in s['operand']]
        self.assertEqual(external,[])
        self.assertFalse(any(target in str(b['arguments']) and b['entry']!=w['entry']
                             for b in self.census['registration_bootstraps']))
        registrations=[(m['entry'],m['method'],s['offset']) for m in self.census['methods']
                       for s in decode_sites(self.census,m,'calls')
                       if '/IEventBus.register(Ljava/lang/Object;)V' in s['operand']]
        self.assertEqual(registrations,[('net/arphex/ArphexMod.class','<init>',8)])
        root=next(w for w in read_json(OUT/'native-evidence/arphex-status-core.json')['witnesses'] if w['entry']=='net/arphex/ArphexMod.class')
        ctor=next(m for m in root['methods'] if m['name']=='<init>')
        before=next(i for i in ctor['instructions'] if i['offset']==7)
        self.assertEqual(before['opcode'],'0x2a') # register(this), not a procedure class
        tick=next(m for m in self.census['methods'] if m['entry']==root['entry'] and m['method']=='tick')
        self.assertFalse(tick['access']&0x8) # instance handler matches register(this)

    def test_mob_disable_list_preserves_literal_native_defaults(self):
        config=next(w for w in self.native['witnesses'] if w['entry'].endswith('/ConfigurationSettingsConfiguration.class'))
        body=config['methods'][0]['instructions']
        at=next(n for n,i in enumerate(body) if 'List.of(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)' in str(i['operand']))
        defaults=[i['operand'] for i in body[at-3:at]]
        self.assertEqual(defaults,['mob_id','mob_id','mob_id (add as many as needed, e.g. spider_snatcher)'])
        row=next(r for r in self.batch['effects'] if r['id']=='arphex:global_entity_join_admission')
        self.assertEqual(row['binary_parameters']['disable_specific_mobs_default'],defaults)

    def test_global_resistance_is_under_living_gate_not_species_gate(self):
        body=next(m['instructions'] for m in self.witness('BloodWormOnInitialEntitySpawnProcedure')['methods']
                  if m['name']=='execute' and any(i['offset']==533 for i in m['instructions']))
        at=next(n for n,i in enumerate(body) if i['offset']==533)
        self.assertEqual([i['operand'] for i in body[at-4:at]],[40,0,0,0])
        types=[i['operand'] for i in body[:at] if i['opcode']=='0xc1']
        self.assertEqual(types[-1],'net/minecraft/world/entity/LivingEntity')
        self.assertIn('DAMAGE_RESISTANCE',body[at-5]['operand'])

    def test_motion_cleanup_uses_component_sum_not_magnitude(self):
        body=next(m['instructions'] for m in self.witness('EntityJoinsWorldProcedure')['methods']
                  if m['name']=='execute' and any('Math.abs(D)' in str(i['operand']) for i in m['instructions']))
        at=next(n for n,i in enumerate(body) if 'Math.abs(D)' in str(i['operand']))
        self.assertEqual(sum(i['opcode']=='0x63' for i in body[max(0,at-20):at]),2)
        self.assertEqual(body[at+1]['operand'],0.001)
        self.assertEqual(abs(1+(-1)+0),0)
        self.assertNotEqual((1**2+(-1)**2+0**2)**0.5,0)

    def test_zero_sleep_hurt_and_native_map_coordinate_typo_are_preserved(self):
        w=self.witness('PlayerSleepsProcedure')
        body=next(m['instructions'] for m in w['methods'] if m['name']=='lambda$execute$0')
        at=next(n for n,i in enumerate(body) if '.hurt(' in str(i['operand']))
        self.assertEqual(body[at-1]['operand'],0.0)
        self.assertEqual(body[at+1]['opcode'],'0x57')
        main=next(m['instructions'] for m in w['methods'] if m['name']=='execute' and any('tormentor_healthD' in str(i['operand']) for i in m['instructions']))
        self.assertEqual(sum('tormentor_yD' in str(i['operand']) for i in main),4)
        self.assertEqual(sum('tormentor_zD' in str(i['operand']) for i in main),0)

    def test_visual_scale_name_does_not_exclude_physical_dimensions(self):
        reader=next(m for m in self.census['methods'] if m['entry']=='net/arphex/entity/ScorpioidBloodlusterEntity.class' and m['method']=='getDefaultDimensions')
        self.assertTrue(any('ScorpioidBloodlusterEntityVisualScaleProcedure.execute(' in s['operand'] for s in decode_sites(self.census,reader,'calls')))
        excluded={r['entry'] for r in self.batch['exclusions']}
        self.assertNotIn('net/arphex/procedures/ScorpioidBloodlusterEntityVisualScaleProcedure.class',excluded)

    def body(self,procedure,name='execute'):
        return max((m['instructions'] for m in self.witness(procedure)['methods'] if m['name']==name),key=len)

    def test_shared_batch_validates_consumers_without_duplicate_records(self):
        batch=read_json(OUT/'arphex-r2m2k-small-shared-global-roots.json')
        review=read_json(OUT/'mod-reviews/arphex.json');ids={r['id'] for r in batch['effects']}
        review['effects']=[r for r in review['effects'] if r['id'] not in ids]
        review['paths']=[p for p in review['paths'] if not set(p['effect_ids'])&ids]
        result=validate_batch(batch,review,self.census)
        self.assertEqual(result['semantic_records'],len(review['effects'])+3)
        self.assertEqual(sum(len(c['parameters']) for r in batch['effects'] for c in r['scalable_parameter_candidates']),9)

    def test_climb_delivery_uses_captured_position_and_current_yaw_without_rechecks(self):
        main=self.body('ClimbingProcedure');by_offset={i['offset']:i for i in main}
        self.assertEqual([by_offset[n]['operand'] for n in (542,725,754)],[13,13,10])
        capture=next(i for i in main if i['offset']==507)
        self.assertIn('LevelAccessor;DDDLnet/minecraft/world/entity/Entity;',capture['operand'])
        status=self.body('ClimbingProcedure','lambda$execute$0')
        at=next(n for n,i in enumerate(status) if i['offset']==360)
        self.assertEqual([i['operand'] for i in status[at-4:at]],[50,1,0,0])
        self.assertIn('SLOW_FALLING',status[at-5]['operand'])
        self.assertTrue(any(i['operand']=='climbradius' for i in status))
        self.assertFalse(any(any(s in str(i['operand']) for s in ('isVehicle','isInWater','isAlive','getTarget','arphexclimber')) for i in status))
        for name in ('lambda$execute$1','lambda$execute$2'):
            motion=self.body('ClimbingProcedure',name)
            self.assertEqual(sum('getYRot()' in str(i['operand']) for i in motion),2)
            self.assertEqual([i['operand'] for i in motion if isinstance(i['operand'],float) and i['operand'] in (.0299,.15)],[.0299,.15,.0299])
            self.assertFalse(any('branch_target' in i for i in motion))
            self.assertEqual(motion[-2]['offset'],49)
            self.assertIn('.setDeltaMovement(',motion[-2]['operand'])

    def test_world_countdown_reset_is_exact_floor_gate_without_spawn(self):
        body=self.body('WorldTickProcedure');at=next(n for n,i in enumerate(body) if i['offset']==984)
        self.assertEqual([body[n]['operand'] for n in (at-2,at,at+1)],[6.0,'java/lang/Math.floor(D)D',1.0])
        self.assertEqual(body[at-1]['opcode'],'0x6f')
        self.assertEqual(body[at+3]['branch_target'],1094)
        hp=next(n for n,i in enumerate(body) if i['offset']==1083)
        self.assertEqual(body[hp-1]['operand'],1024.0)
        self.assertIn('tormentor_healthD',body[hp]['operand'])
        self.assertFalse(any(any(s in str(i['operand']) for s in ('EntityType.spawn','addFreshEntity','queueServerWork','.hurt(','.addEffect(')) for i in body))
        row=next(r for r in read_json(OUT/'arphex-r2m2k-small-shared-global-roots.json')['effects'] if r['id']=='arphex:shared_native_world_state_tick')
        self.assertEqual(row['scalable_parameter_candidates'],[])

    def test_overlay_is_native_darkness_and_chat_replies_are_message_commands(self):
        main=self.body('GameModeDetectorProcedure');at=next(n for n,i in enumerate(main) if i['offset']==1950)
        self.assertEqual([i['operand'] for i in main[at-4:at]],[3,0,0,0])
        self.assertIn('DARKNESS',main[at-5]['operand'])
        gate=next(i for i in main if i['offset']==1908);self.assertEqual(gate['branch_target'],1969)
        self.assertEqual(next(i for i in main if i['offset']==1957)['operand'],8)
        clear=self.body('GameModeDetectorProcedure','lambda$execute$14')
        self.assertFalse(any('branch_target' in i for i in clear))
        self.assertEqual(next(i for i in clear if i['offset']==12)['operand'],0)
        self.assertIn('show_tormentor_overlayZ',next(i for i in clear if i['offset']==13)['operand'])
        chat=self.witness('PlayerChatTormentorProcedure')
        recipes={b['index']:b['arguments'][0] for b in self.census['registration_bootstraps']
                 if b['entry']==chat['entry'] and 'StringConcatFactory' in b['handle']}
        for method in chat['methods']:
            if not method['name'].startswith('lambda$execute$'):continue
            ins=method['instructions'];command=next(n for n,i in enumerate(ins) if '.performPrefixedCommand(' in str(i['operand']))
            argument=ins[command-1]['operand']
            if ins[command-1]['opcode']=='0xba':
                argument=recipes[int(argument.split(':')[0].split('#')[1])]
            self.assertTrue(argument.startswith('/tellraw @a '),method['name'])
            self.assertFalse(any(any(s in str(i['operand']) for s in ('.hurt(','.heal(','.addEffect(','.setDeltaMovement(')) for i in ins))
        self.assertTrue(any('show_tormentor_overlayZ' in str(i['operand']) and i['opcode']=='0xb5' for i in self.body('PlayerChatTormentorProcedure')))

    def test_spider_moth_scale_external_consumer_is_renderer_only_and_reproduces(self):
        getter='net/arphex/procedures/SpiderMothDwellerEntityVisualScaleProcedure'
        callers={m['entry'] for m in self.census['methods'] for s in decode_sites(self.census,m,'calls') if getter+'.execute(' in s['operand'] and m['entry']!=getter+'.class'}
        self.assertEqual(callers,{'net/arphex/client/renderer/SpiderMothRenderer.class'})
        native=read_json(OUT/'native-evidence/arphex-shared-reader-contexts.json')
        body=native['witnesses'][0]['methods'][0]['instructions']
        self.assertEqual([i['operand'].split('.')[1] for i in body if i['opcode']=='0xb5'],['scaleHeightF','scaleWidthF'])
        from native_evidence import collect
        from pathlib import Path
        jar=Path('/workspace/.cache/large-mod-campaign/ArPhEx-5.0.2-neoforge-1.21.1.jar')
        if jar.exists():self.assertEqual(collect(read_json(OUT/'native-specifications/arphex-shared-reader-contexts.json'),{'arphex':jar}),native)

    def target_tick_batch(self):
        batch=read_json(OUT/'arphex-r2m2l-target-and-entity-tick-roots.json')
        review=read_json(OUT/'mod-reviews/arphex.json');ids={r['id'] for r in batch['effects']}
        review['effects']=[r for r in review['effects'] if r['id'] not in ids]
        review['paths']=[p for p in review['paths'] if not set(p['effect_ids'])&ids]
        return batch,review

    def test_target_tick_candidates_and_literal_commands_fail_closed_when_detached(self):
        from copy import deepcopy
        batch,review=self.target_tick_batch()
        result=validate_batch(batch,review,self.census)
        self.assertEqual(result['semantic_records'],len(review['effects'])+20)
        ids={r['id'] for r in review['effects']+batch['effects']}
        self.assertTrue(all(s in ids for r in batch['effects'] for s in r.get('canonical_contract_reuse',[])))
        wrong=deepcopy(batch)
        c=next(c for r in wrong['effects'] for c in r['scalable_parameter_candidates'] if 'native_command_binding' in c)
        c['native_command_binding']['command']='effect give @a minecraft:wither 20 20'
        with self.assertRaises(AssertionError):validate_batch(wrong,review,self.census)
        wrong=deepcopy(batch)
        wrong['record_refinements'][0]['candidate_additions'][0]['native_holder_symbol']='net/minecraft/world/effect/MobEffects.DAMAGE_BOOSTLnet/minecraft/core/Holder;'
        with self.assertRaises(AssertionError):validate_batch(wrong,review,self.census)

    def test_target_event_reads_original_target_and_larvae_decrements_wrong_entity(self):
        wrapper=self.body('DwellerTargetProcedure','onEntitySetsAttackTarget')
        self.assertIn('getOriginalAboutToBeSetTarget()',next(i for i in wrapper if i['offset']==30)['operand'])
        self.assertIn('getEntity()',next(i for i in wrapper if i['offset']==34)['operand'])
        body=self.body('DwellerTargetProcedure');by={i['offset']:i for i in body}
        self.assertEqual(by[5005]['opcode'],'0x57') # hurt return discarded before source reset
        self.assertEqual(by[5006]['local_index'],9)
        self.assertEqual(by[5014]['operand'],10.0)
        self.assertEqual(by[5023]['local_index'],8) # destination is original target
        self.assertEqual(by[5031]['local_index'],9) # decrement reads actor
        self.assertEqual(by[5043]['opcode'],'0x67')
        self.assertIn('.putDouble(',by[5044]['operand'])

    def test_moth_target_side_state_and_commands_have_independent_recipient_selection(self):
        body=self.body('DwellerTargetProcedure')
        for key in ('flyvers','chasemode','growattack'):
            sites=[n for n,i in enumerate(body) if i['operand']==key]
            self.assertTrue(sites)
            if key=='growattack':sites=sites[:1] # later source growattack is a distinct branch
            for n in sites:
                self.assertEqual(body[n-2].get('local_index'),8)
        from promote_combat_batch import literal_command_binding
        method=max((m for m in self.witness('DwellerTargetProcedure')['methods'] if m['name']=='execute'),key=lambda m:len(m['instructions']))
        self.assertEqual(literal_command_binding(method,1519)['command'],'effect give @p[distance=..3] minecraft:nausea 4 3')
        clear=literal_command_binding(method,693)['command']
        self.assertIn('limit=1,distance=..7',clear);self.assertNotIn('sort=nearest',clear)

    def test_configured_weakness_uses_other_config_and_resistance_profiles_differ(self):
        body=self.body('EntitiesTickProcedure')
        self.assertTrue(any('OVERALL_DIFFICULTY_LOWER' in str(i['operand']) for i in body if 500<=i['offset']<545))
        self.assertTrue(any('OVERALL_DIFFICULTYL' in str(i['operand']) for i in body if 545<=i['offset']<577))
        self.assertFalse(any('OVERALL_DIFFICULTY_LOWER' in str(i['operand']) for i in body if 545<=i['offset']<577))
        rounded=[i for i in body if 627<=i['offset']<661]
        truncated=[i for i in body if 4123<=i['offset']<4156]
        self.assertTrue(any('Math.round(D)' in str(i['operand']) for i in rounded))
        self.assertFalse(any('Math.round(' in str(i['operand']) for i in truncated))
        self.assertTrue(any(i['opcode']=='0x8e' for i in truncated)) # d2i

    def test_void_spear_damage_has_integer_armor_and_no_native_owner(self):
        body=self.body('EntitiesTickProcedure','lambda$execute$25');at=next(n for n,i in enumerate(body) if i['offset']==1371)
        before=body[at-45:at]
        self.assertIn('0x6c',[i['opcode'] for i in before])
        self.assertTrue(any('DamageTypes.FELL_OUT_OF_WORLD' in str(i['operand']) for i in before))
        self.assertTrue(any('DamageSource.<init>(Lnet/minecraft/core/Holder;)V' in str(i['operand']) for i in before))
        self.assertEqual(body[at+1]['opcode'],'0x57')
        self.assertTrue(any('.discard()' in str(i['operand']) for i in body[at+2:]))
        self.assertFalse(any('getOwner' in str(i['operand']) or 'setOwner' in str(i['operand']) for i in body))

    def test_burn_uses_larger_integer_branch_and_not_clamped_percent_damage(self):
        body=self.body('EntitiesTickProcedure');by={i['offset']:i for i in body}
        self.assertEqual(by[3835]['operand'],400)
        self.assertEqual([by[n]['opcode'] for n in (3865,3866)],['0x6c','0x6c'])
        start=next(n for n,i in enumerate(body) if i['offset']==3835)
        first=next(n for n,i in enumerate(body) if i['offset']==3957)
        comparisons=[i for i in body[start:first] if i['opcode'] in ('0x95','0x96')]
        self.assertTrue(comparisons)
        gate=next(i for i in body if i['offset']==comparisons[0]['offset']+1)
        self.assertEqual(gate['opcode'],'0x9e') # <= jumps past armor-branch hurt to max-health request
        self.assertGreater(gate['branch_target'],3957)
        self.assertLess(gate['branch_target'],4016)
        self.assertEqual(by[4028]['operand'],10.0)
        self.assertEqual(by[3751]['operand'],1.0)

    def test_follow_local_flag_unused_and_only_reachable_status_sites_counted(self):
        body=self.body('EntitiesTickProcedure')
        stores=[i for i in body if i['opcode']=='0x36' and i.get('local_index')==16]
        loads=[i for i in body if i['opcode']=='0x15' and i.get('local_index')==16]
        self.assertTrue(stores);self.assertEqual(loads,[])
        batch,_=self.target_tick_batch();row=next(r for r in batch['effects'] if r['id']=='arphex:forced_owner_tick_follow')
        sites={c['native_consumer']['offset'] for c in row['scalable_parameter_candidates']}
        sites.update(s['offset'] for c in row['scalable_parameter_candidates'] for s in c.get('additional_consumer_sites',[]))
        self.assertTrue({5456,5695}<=sites);self.assertFalse({5378,5617}&sites)
        flag_writes=[i['offset'] for i in body if i['operand']=='donespawn']
        self.assertTrue(flag_writes)
        first_spawn=next(i['offset'] for i in body if 'EntityType.spawn(' in str(i['operand']))
        self.assertLess(flag_writes[0],first_spawn)

    def test_instant_marker_command_passes_duration_in_ticks_and_direct_instance_retains_window(self):
        doc=read_json(OUT/'vanilla-evidence/arphex-instant-marker-command.json')
        instant=next(c for c in doc['classes'] if c['class_name'].endswith('/InstantenousMobEffect'))
        self.assertEqual(next(m for m in instant['methods'] if m['name']=='isInstantenous')['code_hex'],'04ac')
        give=next(c for c in doc['classes'] if c['class_name'].endswith('/EffectCommands'))['methods'][0]
        code=bytes.fromhex(give['code_hex'])
        self.assertEqual(23+int.from_bytes(code[24:26],'big',signed=True),35)
        self.assertEqual(32+int.from_bytes(code[33:35],'big',signed=True),80)
        self.assertFalse(any(i['opcode']=='0x68' for i in give['instructions'] if 26<=i['offset']<=32))
        self.assertEqual(next(i for i in give['instructions'] if i['offset']==53)['operand'],20)
        base=read_json(OUT/'vanilla-evidence/twilight-ominous-progression.json')
        apply=next(m for c in base['classes'] for m in c['methods'] if c['class_name'].endswith('/MobEffect') and m['name']=='applyEffectTick')
        self.assertEqual(apply['code_hex'],'04ac')
        direct=read_json(OUT/'reference-evidence/cataclysm-shared-244.json')
        method=next(m for w in direct['witnesses'] for m in w.get('methods',[]) if w['entry'].endswith('/LivingEntity.class') and m['name']=='addEffect' and 'Entity;)Z' in m['descriptor'])
        self.assertTrue(any('Map.put(' in str(i['operand']) for i in method['instructions']))
        self.assertFalse(any('isInstantenous' in str(i['operand']) for i in method['instructions']))
        from pathlib import Path
        from vanilla_reference import prepare_raw
        cache=Path('/workspace/.cache/large-mod-campaign/vanilla')
        if (cache/'client.jar').exists():self.assertEqual(prepare_raw(read_json(OUT/'vanilla-specifications/arphex-instant-marker-command.json'),cache/'client.jar',cache/'client_mappings.txt',cache/'version.json'),doc)

    def test_target_tendril_owner_two_launches_and_double_clock_decrement(self):
        body=self.body('DwellerTargetProcedure');by={i['offset']:i for i in body}
        self.assertIn('$4.getArrow(',by[5958]['operand']);self.assertIn('$5.getArrow(',by[6082]['operand'])
        self.assertEqual([by[n]['operand'] for n in (5956,5957,6080,6081)],[2,3,2,3])
        self.assertEqual([by[n]['operand'] for n in (6173,6238)],[1.0,1.0])
        for p in ('DwellerTargetProcedure$4','DwellerTargetProcedure$5'):
            native=self.body(p,'getArrow');n=next(n for n,i in enumerate(native) if '.setOwner(' in str(i['operand']))
            self.assertEqual(native[n-1]['opcode'],'0x2c') # shooter local2
            self.assertEqual(next(i for i in native if i['offset']==45)['operand'],100.0)

    def test_death_batch_merges_scarab_and_validates_exact_consumers(self):
        batch=read_json(OUT/'arphex-r2m2m-sourceful-death-and-shared-completion.json')
        review=read_json(OUT/'mod-reviews/arphex.json');ids={r['id'] for r in batch['effects']}
        review['effects']=[r for r in review['effects'] if r['id'] not in ids]
        review['paths']=[p for p in review['paths'] if not set(p['effect_ids'])&ids]
        result=validate_batch(batch,review,self.census)
        self.assertEqual(result['semantic_records'],len(review['effects'])+9)
        self.assertEqual([r['id'] for r in batch['record_refinements']],['arphex:scarab_native_family'])
        self.assertNotIn('arphex:scarab_native_family',ids)

    def test_death_requires_causing_actor_and_scarab_cancel_does_not_return(self):
        wrapper=self.body('EntityDiesProcedure','onEntityDeath')
        self.assertTrue(any('DamageSource.getEntity()' in str(i['operand']) for i in wrapper))
        self.assertFalse(any('getDirectEntity' in str(i['operand']) for i in wrapper))
        body=self.body('EntityDiesProcedure');by={i['offset']:i for i in body}
        self.assertEqual([by[n].get('local_index') for n in (0,5)],[8,9])
        self.assertEqual([by[n]['branch_target'] for n in (2,7)],[10,11])
        self.assertEqual(by[10]['opcode'],'0xb1')
        self.assertEqual([by[n]['operand'].split('.')[-1].split('(')[0] for n in (3632,3655,3674,3692)],
                         ['setCanceled','setHealth','setCanceled','discard'])
        self.assertFalse(any(i['opcode']=='0xb1' for i in body if 3632<=i['offset']<3695))
        self.assertTrue(any('TORMENTOREntity' in str(i['operand']) for i in body if i['offset']>3692))

    def test_nearest_core_short_circuits_shared_helper_and_wasp_is_not_bound_to_spawn(self):
        core=self.body('EntityDiesProcedure','lambda$execute$21');by={i['offset']:i for i in core}
        self.assertIn('CORE_OF_ETERNAL_SUFFERING',by[163]['operand'])
        self.assertEqual(by[169]['branch_target'],239)
        self.assertIn('TORMENTOREntityDiesProcedure.execute(',by[236]['operand'])
        self.assertEqual(by[239]['opcode'],'0xb1')
        wasp=self.body('EntityDiesProcedure','lambda$execute$18')
        self.assertEqual(sum('getEntitiesOfClass(' in str(i['operand']) for i in wasp),2)
        self.assertTrue(any('DATA_size' in str(i['operand']) for i in wasp))
        self.assertFalse(any('setOwner' in str(i['operand']) for i in wasp))
        main=self.body('EntityDiesProcedure');by={i['offset']:i for i in main}
        self.assertIn('LevelAccessor;DDD)',by[4629]['operand']) # queue captures world/XYZ, not spawned entity

    def test_conduit_requests_native_heal_on_causer_and_capture_statuses_stay_separate(self):
        body=self.body('EntityDiesProcedure');by={i['offset']:i for i in body}
        self.assertEqual([by[n]['operand'] for n in (6099,6100,6101,6102)],[1,0,0,0])
        from promote_combat_batch import effect_receiver_binding,effect_holder_binding
        method=max((m for m in self.witness('EntityDiesProcedure')['methods'] if m['name']=='execute'),key=lambda m:len(m['instructions']))
        self.assertEqual(effect_receiver_binding(method,6103)['origin_local_index'],9)
        self.assertIn('MobEffects.HEAL',effect_holder_binding(method,6103)[0])
        holders=[effect_holder_binding(method,n)[0].split('MobEffects.')[1].split('Lnet/')[0]
                 for n in (5266,5314,5361,5409,5457)]
        self.assertEqual(holders,['BLINDNESS','DARKNESS','CONFUSION','WEAKNESS','DIG_SLOWDOWN'])
        self.assertFalse(any('.hurt(' in str(i['operand']) for i in body))

    def test_shared_completion_intrinsic_callers_native_guard_and_evidence_reproduce(self):
        native=read_json(OUT/'native-evidence/arphex-death-reader-contexts.json')
        helper=next(w for w in native['witnesses'] if w['entry'].endswith('/TORMENTOREntityDiesProcedure.class'))
        method=next(m for m in helper['methods'] if m['name']=='execute')
        self.assertEqual(method['descriptor'],'(Lnet/minecraft/world/level/LevelAccessor;DDD)V')
        by={i['offset']:i for i in method['instructions']}
        self.assertEqual([by[n]['branch_target'] for n in (11,23)],[2081,2081])
        self.assertEqual(by[30]['operand'],2000.0)
        self.assertEqual(by[2051]['operand'],1)
        self.assertIn('setVisualOnly',by[2052]['operand'])
        for w in native['witnesses']:
            if '/entity/' not in w['entry']:continue
            body=w['methods'][0]['instructions']
            self.assertIn('Monster.die(',body[2]['operand'])
            self.assertIn('TORMENTOREntityDiesProcedure.execute(',body[-2]['operand'])
            self.assertFalse(any('branch_target' in i for i in body))
        from pathlib import Path
        from native_evidence import collect
        jar=Path('/workspace/.cache/large-mod-campaign/ArPhEx-5.0.2-neoforge-1.21.1.jar')
        if jar.exists():self.assertEqual(collect(read_json(OUT/'native-specifications/arphex-death-reader-contexts.json'),{'arphex':jar}),native)

    def test_interaction_batch_exact_consumers_and_follow_producer_merge(self):
        batch=read_json(OUT/'arphex-r2m2n-native-interactions-and-seismic-hazard.json')
        review=read_json(OUT/'mod-reviews/arphex.json');ids={r['id'] for r in batch['effects']}
        review['effects']=[r for r in review['effects'] if r['id'] not in ids]
        review['paths']=[p for p in review['paths'] if not set(p['effect_ids'])&ids]
        self.assertEqual(validate_batch(batch,review,self.census)['semantic_records'],len(review['effects'])+12)
        self.assertEqual([r['id'] for r in batch['record_refinements']],['arphex:forced_owner_tick_follow'])

    def test_interaction_event_roles_and_native_stop_use_order(self):
        left=self.body('HitBlockProcedure','onLeftClickBlock')
        self.assertTrue(any('getFace()' in str(i['operand']) for i in left))
        self.assertFalse(any('getHand()' in str(i['operand']) for i in left))
        right=self.body('RightClickEntityProcedure','onRightClickEntity')
        self.assertTrue(any('isClientSide()' in str(i['operand']) for i in right))
        self.assertLess(next(i['offset'] for i in right if 'getTarget()' in str(i['operand'])),
                        next(i['offset'] for i in right if 'getX()' in str(i['operand'])))
        body=self.body('RightClickEntityProcedure')
        self.assertLess(next(i['offset'] for i in body if 'stopUsingItem()' in str(i['operand'])),
                        next(i['offset'] for i in body if 'isUsingItem()' in str(i['operand'])))
        self.assertFalse(any('setCanceled' in str(i['operand']) for i in body))

    def test_block_impulse_is_absolute_and_chaos_clear_has_two_independent_literals(self):
        body=self.body('HitBlockProcedure');by={i['offset']:i for i in body}
        segment=[i for i in body if 2557<=i['offset']<=3180]
        self.assertEqual(sum('setDeltaMovement(' in str(i['operand']) for i in segment),4)
        self.assertEqual(sum(i['operand']==.3 for i in segment),4)
        self.assertFalse(any(any(s in str(i['operand']) for s in ('knockback(','getOwner','hurt(','normalize(')) for i in segment))
        from promote_combat_batch import literal_command_binding
        method=max((m for m in self.witness('HitBlockProcedure')['methods'] if m['name']=='execute'),key=lambda m:len(m['instructions']))
        self.assertEqual(literal_command_binding(method,3298)['command'],'effect clear @e[distance=..40] arphex:chaos_controlled')
        self.assertEqual(literal_command_binding(method,3371)['command'],'effect clear @e[distance=..40] arphex:chaos_target')
        self.assertEqual(by[2554]['operand'],5.0)

    def interaction_witness(self,name):
        return next(w for w in read_json(OUT/'native-evidence/arphex-interaction-readers.json')['witnesses']
                    if w['entry'].endswith('/'+name+'.class'))

    def test_blockwave_authored_spawns_and_nested_timing_are_not_idealized_ring(self):
        wave=self.interaction_witness('BlockwaveProcedure')
        methods=[m for m in wave['methods'] if m['name']=='execute' or m['name'].startswith('lambda')]
        counts=[sum('EntityType.spawn(' in str(i['operand']) for i in m['instructions']) for m in methods]
        self.assertEqual(counts,[1,4,8,12,16,24,36,44,48,52])
        self.assertEqual(sum(counts),245)
        intervals=[]
        for m in methods:
            b=m['instructions']
            for n,i in enumerate(b):
                if '.queueServerWork(' in str(i['operand']):intervals.append(b[n-6]['operand'])
            self.assertFalse(any(any(s in str(i['operand']) for s in ('setOwner','hurt(','destroyBlock(','setBlock(')) for i in b))
        self.assertEqual(intervals,[4,4,3,3,3,3,2,2,2])
        # Two independently emitted requests for the literal (-3,0,-2)
        # prove this stage is not an idealized unique-point perimeter.
        ring=next(m['instructions'] for m in methods if m['name']=='lambda$execute$4')
        points=[]
        for n,i in enumerate(ring):
            if 'BlockPos.containing(DDD)' not in str(i['operand']):continue
            window=ring[n-7:n]
            if [x['opcode'] for x in window]==['0x27','0x14','0x67','0x29','0x18','0x14','0x67']:
                if window[1]['operand']==3.0 and window[5]['operand']==2.0:
                    points.append(i['offset'])
        self.assertEqual(len(points),2)
        # Full native method remains the source; canonical metadata must retain
        # its explicit repeated offsets rather than deduplicating its requests.
        batch=read_json(OUT/'arphex-r2m2n-native-interactions-and-seismic-hazard.json')
        row=next(r for r in batch['effects'] if r['id']=='arphex:seismic_blockwave_native_delivery')
        stage=next(s for c in row['components'] if c['primitive']=='NATIVE_HAZARD_STENCIL'
                   for s in c['numerical_parameters']['native_stages'] if s['method']=='lambda$execute$4')
        self.assertIn({'offset':[-3.0,0.0,-2.0],'requests':2},stage['repeated_offsets'])

    def test_blocktest_damage_integer_division_independent_motion_and_zero_melee(self):
        hazard=self.interaction_witness('BlockTestOnEntityTickUpdateProcedure')
        body=next(m['instructions'] for m in hazard['methods'] if m['name']=='lambda$execute$11')
        damage=next(n for n,i in enumerate(body) if i['offset']==479)
        self.assertIn('0x6c',[i['opcode'] for i in body[damage-25:damage]])
        self.assertEqual(body[damage+1]['opcode'],'0x57')
        self.assertTrue(any('DamageSource.<init>(Lnet/minecraft/core/Holder;)V' in str(i['operand']) for i in body[:damage]))
        self.assertEqual(sum('.setDeltaMovement(' in str(i['operand']) for i in body),5)
        self.assertFalse(any('setOwner' in str(i['operand']) or 'destroyBlock(' in str(i['operand']) for i in body))
        from promote_combat_batch import literal_attribute_binding
        method=next(m for m in self.interaction_witness('BlockTestEntity')['methods'] if m['name']=='createAttributes')
        bindings=[literal_attribute_binding(method,i['offset']) for i in method['instructions']
                  if 'AttributeSupplier$Builder.add(' in str(i['operand'])]
        attack=next(b for b in bindings if '/Attributes.ATTACK_DAMAGE' in b['attribute_symbol'])
        self.assertEqual(attack['native_value'],0.0)

    def test_interaction_reader_evidence_reproduces_exact_selected_classes(self):
        from pathlib import Path
        from native_evidence import collect
        jar=Path('/workspace/.cache/large-mod-campaign/ArPhEx-5.0.2-neoforge-1.21.1.jar')
        if jar.exists():self.assertEqual(collect(read_json(OUT/'native-specifications/arphex-interaction-readers.json'),{'arphex':jar}),
                                       read_json(OUT/'native-evidence/arphex-interaction-readers.json'))

    def test_block_use_batch_exact_consumers_and_explosion_primitive_fail_closed(self):
        from copy import deepcopy
        batch=read_json(OUT/'arphex-r2m2o-block-use-altar-and-repellant.json')
        review=read_json(OUT/'mod-reviews/arphex.json');ids={r['id'] for r in batch['effects']}
        review['effects']=[r for r in review['effects'] if r['id'] not in ids]
        review['paths']=[p for p in review['paths'] if not set(p['effect_ids'])&ids]
        self.assertEqual(validate_batch(batch,review,self.census)['semantic_records'],len(review['effects'])+7)
        bad=deepcopy(batch)
        row=next(r for r in bad['effects'] if r['id']=='arphex:altar_native_explosion_delivery')
        row['scalable_parameter_candidates'][0]['primitive']='FORCED_MOVEMENT'
        with self.assertRaises(AssertionError):validate_batch(bad,review,self.census)

    def test_block_use_hand_admission_and_summon_cooldown_reads_current_mainitem(self):
        wrapper=self.body('RightClickBlockProcedure','onRightClickBlock')
        by={i['offset']:i for i in wrapper}
        self.assertIn('getHand()',by[1]['operand'])
        self.assertIn('getUsedItemHand()',by[8]['operand'])
        self.assertEqual(by[11]['branch_target'],15)
        self.assertEqual(by[14]['opcode'],'0xb1')
        delivery=self.body('RightClickBlockProcedure','lambda$execute$33')
        by={i['offset']:i for i in delivery}
        self.assertIn('getMainHandItem()',by[611]['operand'])
        self.assertIn('getItem()',by[620]['operand'])
        self.assertEqual(by[623]['operand'],200)
        self.assertIn('addCooldown(',by[626]['operand'])
        self.assertFalse(any('MOTH_SUMMONER' in str(i['operand']) for i in delivery))

    def test_altar_failed_pattern_moth_blast_and_native_anonymous_none_explosion(self):
        moth=self.body('SummonAltarProcedure','lambda$execute$10')
        scorpion=self.body('SummonAltarProcedure','lambda$execute$21')
        self.assertEqual({i['branch_target'] for i in moth if i['offset'] in (19,43,72)},{875})
        self.assertEqual({i['branch_target'] for i in scorpion if i['offset'] in (60,84,113)},{889})
        for body in (moth,scorpion):
            by={i['offset']:i for i in body}
            self.assertEqual(by[875]['operand'],1)
            self.assertIn('queueServerWork(',by[886]['operand'])
            self.assertEqual(by[889]['opcode'],'0xb1')
        for name in ('lambda$execute$9','lambda$execute$20','lambda$execute$29','lambda$execute$41','lambda$execute$50'):
            blast=self.body('SummonAltarProcedure',name);by={i['offset']:i for i in blast}
            self.assertEqual(by[23]['opcode'],'0x1') # null actor
            self.assertEqual(by[28]['operand'],6.0)
            self.assertIn('ExplosionInteraction.NONE',by[31]['operand'])
            self.assertIn('Level.explode(',by[34]['operand'])
            self.assertEqual(by[37]['opcode'],'0x57') # ignores native result
        wrong=self.body('SummonAltarProcedure','lambda$execute$29')
        self.assertTrue(any('SpiderMothDwellerEntity' in str(i['operand']) for i in wrong))
        self.assertFalse(any('DraconicVoidlasher' in str(i['operand']) for i in wrong))

    def test_repellant_rechecks_marker_and_command_has_no_source_actor(self):
        witness=self.interaction_witness('RepellantTickProcedure')
        main=next(m for m in witness['methods'] if m['name']=='execute')
        by={i['offset']:i for i in main['instructions']}
        self.assertEqual(by[32]['operand'],20)
        self.assertIn('queueServerWork(',by[41]['operand'])
        self.assertEqual([by[n]['operand'] for n in (217,219,220,221)],[20,1,0,0])
        self.assertEqual(by[286]['opcode'],'0x1')
        from promote_combat_batch import literal_command_binding
        self.assertEqual(literal_command_binding(main,295)['command'],
                         'effect give @e[type=!player,distance=..30] arphex:repulsion 1 1 false')
        delayed=next(m['instructions'] for m in witness['methods'] if m['name']=='lambda$execute$0')
        by={i['offset']:i for i in delayed}
        self.assertIn('hasEffect(',by[16]['operand'])
        self.assertEqual([by[n]['branch_target'] for n in (19,29)],[36,36])
        self.assertIn('discard()',by[33]['operand'])
        entity=self.interaction_witness('RepellantEntity')
        self.assertFalse(any(m['name']=='doHurtTarget' for m in entity['methods']))
        goals=[m for m in entity['methods'] if m['name']=='registerGoals']
        self.assertFalse(any('addGoal(' in str(i['operand']) for m in goals for i in m['instructions']))

    def test_dimension_batch_exact_consumers_and_existing_payload_reuse(self):
        from copy import deepcopy
        batch=read_json(OUT/'arphex-r2m2p-dimension-weather-and-shield-reader.json')
        review=read_json(OUT/'mod-reviews/arphex.json');ids={r['id'] for r in batch['effects']}
        review['effects']=[r for r in review['effects'] if r['id'] not in ids]
        review['paths']=[p for p in review['paths'] if not set(p['effect_ids'])&ids]
        self.assertEqual(validate_batch(batch,review,self.census)['semantic_records'],len(review['effects'])+6)
        self.assertEqual(sum(len(c['parameters']) for r in batch['effects'] for c in r['scalable_parameter_candidates']),9)
        for row in batch['effects']:
            for rid in row.get('canonical_contract_reuse',[]):
                self.assertIn(rid,{r['id'] for r in review['effects']})
        bad=deepcopy(batch);bad['effects'][0]['canonical_contract_reuse']=['arphex:missing_contract']
        with self.assertRaisesRegex(AssertionError,'unknown/self canonical reuse'):
            validate_batch(bad,review,self.census)

    def test_breathless_threshold_is_admission_and_conditional_duration_keeps_recipient(self):
        body=self.body('DimensionTickProcedure');by={i['offset']:i for i in body}
        self.assertEqual(by[4460]['operand'],150)
        self.assertEqual(by[4463]['branch_target'],5055)
        self.assertEqual([by[n]['local_index'] for n in (4474,4479,4492)],[8,113,113])
        self.assertEqual(by[4476]['operand'],'net/minecraft/world/entity/LivingEntity')
        self.assertEqual([by[n]['operand'] for n in (4501,4542,4544)],[3,0,1])
        self.assertEqual([by[n]['opcode'] for n in (4543,4545)],['0x60','0x60'])
        self.assertIn('getDuration()',by[4536]['operand'])
        self.assertIn('addEffect(',by[4552]['operand'])
        self.assertFalse(any(i.get('branch_target',-1) in range(4474,4500) for i in body))
        # The only writes to the recipient local precede its allocation/load;
        # branches for the duration keep that receiver below their own stack.
        self.assertFalse(any(i.get('local_index')==113 and i['opcode']=='0x3a'
                             for i in body if 4492<i['offset']<=4552))
        self.assertEqual(149+3+1,153)

    def test_dimension_damage_has_holder_only_sources_and_paused_native_cadence(self):
        body=self.body('DimensionTickProcedure');by={i['offset']:i for i in body}
        self.assertEqual([by[n]['operand'] for n in (293,706,4186)],[10.0,1.0,12.0])
        for at in (295,707,4189):
            index=next(n for n,i in enumerate(body) if i['offset']==at)
            self.assertIn('DamageSource.<init>(Lnet/minecraft/core/Holder;)V',body[index-2]['operand'])
            self.assertEqual(body[index+1]['opcode'],'0x57')
        self.assertEqual(by[4162]['operand'],400.0)
        self.assertIn('putDouble(',by[4165]['operand'])
        self.assertIn('getDouble(',by[4250]['operand'])
        self.assertEqual(by[4253]['operand'],1.0)
        self.assertEqual(by[4254]['opcode'],'0x67')

    def test_shield_writes_absolute_raw_vector_before_projectile_speed_and_uuid(self):
        body=self.body('DimensionTickProcedure');by={i['offset']:i for i in body}
        self.assertEqual(by[5578]['operand'],3.0)
        self.assertEqual(by[6357]['operand'],10.0)
        motion=[i for i in body if 6510<=i['offset']<=6670]
        self.assertEqual(sum('setDeltaMovement(' in str(i['operand']) for i in motion),1)
        vector_fields=[i['operand'] for i in motion if i['operand'] in ('x_lock_shield','y_lock_shield','z_lock_shield')]
        self.assertEqual(vector_fields,['x_lock_shield','y_lock_shield','z_lock_shield'])
        after=[i for i in motion if i['offset']>6604]
        self.assertTrue(any('Vec3.length()' in str(i['operand']) for i in after))
        self.assertEqual(by[6648]['operand'],'net/minecraft/nbt/CompoundTag.putBoolean(Ljava/lang/String;Z)V')
        self.assertFalse(any('normalize(' in str(i['operand']) or 'hurt(' in str(i['operand']) for i in motion))

    def test_player_control_batch_exact_consumers_without_claiming_remaining_method_closed(self):
        batch=read_json(OUT/'arphex-r2m2q-player-gaze-grab-mount-and-flight.json')
        review=read_json(OUT/'mod-reviews/arphex.json');ids={r['id'] for r in batch['effects']}
        review['effects']=[r for r in review['effects'] if r['id'] not in ids]
        review['paths']=[p for p in review['paths'] if not set(p['effect_ids'])&ids]
        self.assertEqual(validate_batch(batch,review,self.census)['semantic_records'],len(review['effects'])+12)
        self.assertEqual(sum(len(c['parameters']) for r in batch['effects'] for c in r['scalable_parameter_candidates']),68)
        self.assertFalse(batch['whole_mod_complete'])
        self.assertIn('10721',batch['exact_next_task'])
        for row in batch['effects']:
            for candidate in row['scalable_parameter_candidates']:
                if candidate['primitive'] in ('MOB_EFFECT_MOTH_CURSE','MOB_EFFECT_REPULSION','MOB_EFFECT_BLINDNESS'):
                    self.assertFalse(any('amplifier' in p for p in candidate['parameters']))

    def test_grab_early_normal_larvae_gate_and_post_payload_cleanup_order(self):
        body=self.body('GameModeDetectorProcedure');by={i['offset']:i for i in body}
        first=[i for i in body if 2585<=i['offset']<=2656]
        self.assertTrue(any(i['operand']=='net/arphex/entity/SpiderLarvaeEntity' for i in first))
        self.assertFalse(any('SpiderLarvaeTiny' in str(i['operand']) for i in first))
        self.assertIn('putBoolean(',by[2653]['operand'])
        self.assertLess(2653,2785) # clear before raw creative-mode update
        self.assertLess(4071,4218) # request before near-family cleanup
        self.assertLess(4071,4245) # request before creative cleanup
        self.assertEqual(by[4046]['operand'],30.0)
        self.assertEqual(by[4070]['operand'],1.0)
        self.assertEqual(by[4074]['opcode'],'0x57')
        from promote_combat_batch import literal_command_binding
        method=max((m for m in self.witness('GameModeDetectorProcedure')['methods'] if m['name']=='execute'),key=lambda m:len(m['instructions']))
        for offset in (3859,3930):
            command=literal_command_binding(method,offset)['command']
            self.assertIn('regeneration 1 1 true',command)
            self.assertNotIn('distance=',command)
        self.assertIn('distance=..8',literal_command_binding(method,3717)['command'])
        self.assertIn('distance=..4',literal_command_binding(method,3788)['command'])

    def test_mount_recipient_alias_proofs_match_native_getter_cast_and_load(self):
        witness=self.witness('GameModeDetectorProcedure')
        batch=read_json(OUT/'arphex-r2m2q-player-gaze-grab-mount-and-flight.json')
        checked=0
        for row in batch['effects']:
            for candidate in row['scalable_parameter_candidates']:
                proof=candidate.get('native_recipient_evidence')
                if not proof:continue
                checked+=1;consumer=candidate['native_consumer']
                method=next(m for m in witness['methods'] if m['name']==consumer['methods'][0] and m['descriptor']==consumer['descriptor'])
                by={i['offset']:i for i in method['instructions']}
                self.assertIn('Entity.getVehicle()',by[proof['vehicle_getter_offset']]['operand'])
                self.assertEqual(by[proof['cast_offset']]['operand'],'net/minecraft/world/entity/LivingEntity')
                self.assertIn('LivingEntity.addEffect(',by[proof['add_effect_offset']]['operand'])
                self.assertLess(proof['vehicle_getter_offset'],proof['cast_offset'])
                self.assertLess(proof['cast_offset'],proof['receiver_load_offset'])
        self.assertEqual(checked,5)
        for name in ('lambda$execute$29','lambda$execute$30','lambda$execute$32'):
            delivery=self.body('GameModeDetectorProcedure',name)
            self.assertTrue(any('getVehicle()' in str(i['operand']) for i in delivery))
            self.assertFalse(any('/entity/SpiderMothSummonEntity' in str(i['operand']) or '/entity/TamedTarantulaEntity' in str(i['operand'])
                                 for i in delivery))

    def test_glide_absolute_velocity_reset_and_wrong_void_clear_are_not_corrected_by_prose(self):
        body=self.body('GameModeDetectorProcedure');by={i['offset']:i for i in body}
        self.assertEqual(by[10714]['operand'],'voidnearvoidnear')
        self.assertEqual(by[10717]['operand'],0)
        glide=[i for i in body if 7790<=i['offset']<8100]
        self.assertEqual(sum('.setDeltaMovement(' in str(i['operand']) for i in glide),2)
        self.assertFalse(any(i['operand']=='crafted' or 'bosskills' in str(i['operand']) for i in glide))
        self.assertTrue(any(i['operand']==52000.0 for i in glide))
        self.assertEqual(by[8304]['operand'],.25)
        self.assertEqual(by[8307]['operand'],.05)
        self.assertEqual(by[8310]['operand'],.25)

    def test_player_native_root_reproduces_exact_pinned_method_hashes(self):
        from pathlib import Path
        from native_evidence import collect
        jar=Path('/workspace/.cache/large-mod-campaign/ArPhEx-5.0.2-neoforge-1.21.1.jar')
        if not jar.exists():self.skipTest('pinned artifact not installed in this validation workspace')
        spec=read_json(OUT/'native-specifications/arphex-global-hooks.json')
        entries={'net/arphex/procedures/GameModeDetectorProcedure.class'}
        spec['evidence_specifications']=[s for s in spec['evidence_specifications'] if s['entry'] in entries]
        self.assertEqual(collect(spec,{'arphex':jar})['witnesses'],[self.witness('GameModeDetectorProcedure')])

    def test_equipment_batch_unique_native_consumer_profiles_and_state_merge(self):
        batch=read_json(OUT/'arphex-r2m2r-player-armor-sweep-and-owned-population.json')
        review=read_json(OUT/'mod-reviews/arphex.json');ids={r['id'] for r in batch['effects']}
        review['effects']=[r for r in review['effects'] if r['id'] not in ids]
        review['paths']=[p for p in review['paths'] if not set(p['effect_ids'])&ids]
        self.assertEqual(validate_batch(batch,review,self.census)['semantic_records'],len(review['effects'])+5)
        self.assertEqual(sum(len(c['parameters']) for r in batch['effects'] for c in r['scalable_parameter_candidates']),20)
        self.assertEqual([r['id'] for r in batch['record_refinements']],['arphex:player_shared_native_admission_state'])

    def test_sweep_native_integer_division_phase_factors_and_explicit_damage_actor(self):
        body=self.body('GameModeDetectorProcedure');by={i['offset']:i for i in body}
        self.assertEqual(by[13218]['operand'],5.0)
        self.assertEqual(by[12435]['operand'],25.0)
        for hurt,actor in ((13699,13664),(14516,14481)):
            at=next(n for n,i in enumerate(body) if i['offset']==hurt)
            self.assertEqual([i['opcode'] for i in body[at-3:at]],['0x60','0x6c','0x86'])
            self.assertEqual(by[actor]['local_index'],8)
            self.assertIn('DamageSource.<init>(Lnet/minecraft/core/Holder;Lnet/minecraft/world/entity/Entity;)V',by[actor+2]['operand'])
            self.assertEqual(body[at+1]['opcode'],'0x57')
        for offset,factor in ((13936,10),(14082,10),(14227,10),(14347,10),
                              (14753,20),(14899,20),(15044,20),(15164,20)):
            at=next(n for n,i in enumerate(body) if i['offset']==offset)
            start=max(n for n,i in enumerate(body[:at]) if i['opcode']=='0xbb' and i['operand']=='net/minecraft/world/phys/Vec3')
            vector=body[start:at]
            factors=[i['operand'] for n,i in enumerate(vector[:-1]) if i['opcode']=='0x10' and vector[n+1]['opcode']=='0x68']
            self.assertEqual(factors,[factor,factor])
            self.assertEqual(sum(i['opcode']=='0x6c' for i in vector),2)
            self.assertIn(.3,[i['operand'] for i in vector])
        self.assertEqual(16//(12+5),0)
        self.assertEqual(300//(200+11*10),0)
        self.assertEqual(300//(200+6*20),0)

    def test_ant_typed_key_collision_and_queen_flag_consumption_are_native(self):
        body=self.body('GameModeDetectorProcedure');by={i['offset']:i for i in body}
        self.assertEqual(by[15576]['operand'],'furthest_ant')
        self.assertIn('putDouble(',by[15580]['operand'])
        interval=[i for i in body if 15710<=i['offset']<=15820]
        self.assertTrue(any(i['operand']=='furthest_ant' for i in interval))
        writes=[i for i in interval if any(s in str(i['operand']) for s in ('CompoundTag.putDouble(','CompoundTag.putString('))]
        self.assertEqual(len(writes),2)
        self.assertIn('putDouble(',writes[0]['operand'])
        self.assertIn('putString(',writes[1]['operand'])
        self.assertEqual(by[15960]['operand'],'queenslowtotem')
        self.assertEqual(by[15963]['operand'],0)
        self.assertLess(15964,16084)
        native=read_json(OUT/'vanilla-evidence/arphex-typed-nbt-reads.json')['classes'][0]
        double=next(m for m in native['methods'] if m['name']=='getDouble')
        self.assertEqual(double['instructions'][2]['operand'],99)
        code=bytes.fromhex(double['code_hex'])
        miss=7+int.from_bytes(code[8:10],'big',signed=True)
        self.assertEqual(miss,27)
        self.assertEqual(miss+int.from_bytes(code[miss+1:miss+3],'big',signed=True),31)
        self.assertEqual(next(i for i in double['instructions'] if i['offset']==31)['operand'],0.0)
        typed=next(m for m in native['methods'] if m['name']=='contains' and m['obfuscated_descriptor']=='(Ljava/lang/String;I)Z')
        # Numeric wildcard accepts native numeric IDs1..6, never String ID8.
        kinds=[i['operand'] for i in typed['instructions'] if i['opcode'] in ('0x4','0x5','0x6','0x7','0x8','0x10') and i['offset'] in (20,25,30,35,40,45)]
        self.assertEqual(kinds,[1,2,3,4,5,6])
        string=next(w for w in read_json(OUT/'vanilla-evidence/arphex-typed-nbt-reads.json')['classes']
                    if w['class_name']=='net/minecraft/nbt/StringTag')
        self.assertEqual(string['methods'][0]['name'],'getId')
        self.assertEqual(string['methods'][0]['instructions'][0]['operand'],8)

    def test_typed_nbt_reference_reproduces_only_selected_pinned_methods(self):
        from pathlib import Path
        from vanilla_reference import prepare_raw
        cached=Path('/workspace/.cache/large-mod-campaign/vanilla')
        if not (cached/'client.jar').exists():self.skipTest('pinned Vanilla artifact unavailable')
        self.assertEqual(prepare_raw(read_json(OUT/'vanilla-specifications/arphex-typed-nbt-reads.json'),
                                    cached/'client.jar',cached/'client_mappings.txt',cached/'version.json'),
                         read_json(OUT/'vanilla-evidence/arphex-typed-nbt-reads.json'))


if __name__=='__main__':unittest.main()
